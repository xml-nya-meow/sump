package guard

import (
	"context"
	"errors"
	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/vmihailenco/msgpack/v5"
)

func (id *Identity) Call(ctx context.Context, addr, to, action string, input any) (msgpack.RawMessage, error) {
	return id.CallAs(ctx, addr, to, action, input, "", "")
}

// CallAs binds a caller-selected request ID and boss before asynchronous work starts.
func (id *Identity) CallAs(ctx context.Context, addr, to, action string, input any, requestID, boss string) (msgpack.RawMessage, error) {
	raw, err := protocol.EncodePayload(input)
	if err != nil {
		return nil, err
	}
	env, err := protocol.NewEnvelope(protocol.TypeJump, id.Name, to, "", protocol.JumpPayload{Action: action, Input: raw})
	if err != nil {
		return nil, err
	}
	if requestID != "" {
		env.ID = requestID
	}
	env.Boss = boss
	if err = id.Sign(&env); err != nil {
		return nil, err
	}
	c, err := protocol.DialContext(ctx, addr, nil)
	if err != nil {
		return nil, errors.New("CONNECTION_UNAVAILABLE")
	}
	defer c.Close()
	resp, err := c.Call(ctx, env)
	if err != nil {
		return nil, errors.New("REQUEST_UNCONFIRMED")
	}
	if resp.ID != env.ID || resp.Type != protocol.TypeResponse {
		return nil, errors.New("INVALID_RESPONSE")
	}
	if err = id.Verify(resp, to, false); err != nil {
		return nil, err
	}
	var p protocol.ResponsePayload
	if resp.DecodePayload(&p) != nil {
		return nil, errors.New("INVALID_RESPONSE")
	}
	if !p.OK {
		return nil, errors.New(p.Error)
	}
	return p.Data, nil
}
