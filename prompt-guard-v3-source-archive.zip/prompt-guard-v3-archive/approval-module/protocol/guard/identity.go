// Package guard is the optional v3 authenticated transport and approval wire contract.
package guard

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/safevalue"
)

type Identity struct {
	Name    string            `json:"name"`
	Private string            `json:"private"`
	Peers   map[string]string `json:"peers"`
	mu      sync.Mutex
	seen    map[string]int64
}

func Load(path, name string) (*Identity, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, errors.New("guard identity cannot be read")
	}
	var id Identity
	if safevalue.DecodeStrictObject(b, &id) != nil || id.Name != name {
		return nil, errors.New("guard identity invalid")
	}
	key, err := base64.StdEncoding.DecodeString(id.Private)
	if err != nil || len(key) != ed25519.PrivateKeySize {
		return nil, errors.New("guard private key invalid")
	}
	for peer, encoded := range id.Peers {
		pub, err := base64.StdEncoding.DecodeString(encoded)
		if !safevalue.ValidName(peer) || err != nil || len(pub) != ed25519.PublicKeySize {
			return nil, errors.New("guard peer invalid")
		}
	}
	self, _ := base64.StdEncoding.DecodeString(id.Peers[name])
	if !bytes.Equal(self, ed25519.PrivateKey(key).Public().(ed25519.PublicKey)) {
		return nil, errors.New("guard self key mismatch")
	}
	id.seen = map[string]int64{}
	return &id, nil
}

// Init creates separate private identities. Existing configurations are never overwritten.
func Init(dir string, names []string) error {
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	peers := map[string]string{}
	private := map[string]string{}
	for _, name := range names {
		if !safevalue.ValidName(name) {
			return errors.New("invalid identity name")
		}
		if _, err := os.Stat(filepath.Join(dir, name+".json")); !os.IsNotExist(err) {
			return errors.New("identity already exists or path unavailable")
		}
		pub, key, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return err
		}
		peers[name] = base64.StdEncoding.EncodeToString(pub)
		private[name] = base64.StdEncoding.EncodeToString(key)
	}
	for _, name := range names {
		b, err := json.MarshalIndent(&Identity{Name: name, Private: private[name], Peers: peers}, "", "  ")
		if err != nil {
			return err
		}
		f, err := os.OpenFile(filepath.Join(dir, name+".json"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			return err
		}
		_, err = f.Write(b)
		if err == nil {
			err = f.Sync()
		}
		closeErr := f.Close()
		if err != nil {
			return err
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func signedBytes(e protocol.Envelope) []byte {
	var b bytes.Buffer
	binary.Write(&b, binary.BigEndian, int64(e.V))
	for _, value := range []string{e.ID, e.Trace, e.Boss, e.Type, e.From, e.To, string(e.Payload)} {
		binary.Write(&b, binary.BigEndian, uint64(len(value)))
		b.WriteString(value)
	}
	if e.Auth != nil {
		binary.Write(&b, binary.BigEndian, e.Auth.Time)
	}
	return b.Bytes()
}

func (id *Identity) Sign(e *protocol.Envelope) error {
	if e.From != id.Name {
		return errors.New("guard sender mismatch")
	}
	key, err := base64.StdEncoding.DecodeString(id.Private)
	if err != nil || len(key) != ed25519.PrivateKeySize {
		return errors.New("guard key unavailable")
	}
	e.Auth = &protocol.Authentication{Time: time.Now().Unix()}
	e.Auth.Signature = base64.StdEncoding.EncodeToString(ed25519.Sign(key, signedBytes(*e)))
	return nil
}

func (id *Identity) Verify(e protocol.Envelope, peer string, consume bool) error {
	if e.V != protocol.ProtocolVersion || e.Auth == nil || e.From != peer || e.To != id.Name || len(e.ID) == 0 || len(e.ID) > 128 {
		return errors.New("AUTH_REQUIRED")
	}
	now := time.Now().Unix()
	if e.Auth.Time < now-30 || e.Auth.Time > now+30 {
		return errors.New("AUTH_EXPIRED")
	}
	pub, err := base64.StdEncoding.DecodeString(id.Peers[peer])
	if err != nil || len(pub) != ed25519.PublicKeySize {
		return errors.New("AUTH_PEER")
	}
	sig, err := base64.StdEncoding.DecodeString(e.Auth.Signature)
	if err != nil || !ed25519.Verify(pub, signedBytes(e), sig) {
		return errors.New("AUTH_SIGNATURE")
	}
	if !consume {
		return nil
	}
	id.mu.Lock()
	defer id.mu.Unlock()
	if id.seen == nil {
		id.seen = map[string]int64{}
	}
	for key, expiry := range id.seen {
		if expiry < now {
			delete(id.seen, key)
		}
	}
	key := peer + ":" + e.Type + ":" + e.ID
	if _, exists := id.seen[key]; exists {
		return errors.New("AUTH_REPLAY")
	}
	if len(id.seen) >= 8192 {
		return errors.New("AUTH_BUSY")
	}
	id.seen[key] = e.Auth.Time + 31
	return nil
}
