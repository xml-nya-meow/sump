package guard

import (
 "path/filepath"
 "testing"
 "github.com/QAQ-awa-QAQ/sump/protocol"
)

func TestSignedRequestBindsPayloadRecipientAndReplay(t *testing.T) {
 dir:=t.TempDir()
 if err:=Init(dir,[]string{"reasoner","security","memory"});err!=nil{t.Fatal(err)}
 sender,err:=Load(filepath.Join(dir,"reasoner.json"),"reasoner");if err!=nil{t.Fatal(err)}
 receiver,err:=Load(filepath.Join(dir,"security.json"),"security");if err!=nil{t.Fatal(err)}
 e,err:=protocol.NewEnvelope(protocol.TypeJump,"reasoner","security","",map[string]string{"action":"approval_request"});if err!=nil{t.Fatal(err)}
 if err=sender.Sign(&e);err!=nil{t.Fatal(err)}
 altered:=e;altered.To="memory"
 if receiver.Verify(altered,"reasoner",true)==nil{t.Fatal("changed destination accepted")}
 altered=e;altered.Payload=[]byte{0xc0}
 if receiver.Verify(altered,"reasoner",true)==nil{t.Fatal("changed payload accepted")}
 if err=receiver.Verify(e,"reasoner",true);err!=nil{t.Fatal(err)}
 if receiver.Verify(e,"reasoner",true)==nil{t.Fatal("replayed request accepted")}
 if receiver.Verify(e,"operator",false)==nil{t.Fatal("wrong identity accepted")}
}
