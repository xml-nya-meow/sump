package guard

import (
	"errors"
	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/safevalue"
	"github.com/vmihailenco/msgpack/v5"
	"strings"
	"unicode/utf8"
)

const Version = "guard-v3"

type Operation struct {
	Service string             `json:"service" msgpack:"service"`
	Action  string             `json:"action" msgpack:"action"`
	Input   msgpack.RawMessage `json:"-" msgpack:"input"`
}
type Segment struct {
	ID          string `json:"id" msgpack:"id"`
	Source      string `json:"source" msgpack:"source"`
	Text        string `json:"text" msgpack:"text"`
	Sensitivity string `json:"sensitivity" msgpack:"sensitivity"`
}
type Task struct {
	Goal     string `json:"goal" msgpack:"goal"`
	Session  string `json:"session" msgpack:"session"`
	Revision string `json:"revision" msgpack:"revision"`
}
type ContentRequest struct {
	Stage           string         `json:"stage" msgpack:"stage"`
	Task            Task           `json:"task" msgpack:"task"`
	RoleID          string         `json:"role_id" msgpack:"role_id"`
	Segments        []Segment      `json:"segments" msgpack:"segments"`
	Candidate       string         `json:"candidate,omitempty" msgpack:"candidate,omitempty"`
	Command         map[string]any `json:"command,omitempty" msgpack:"command,omitempty"`
	ContextComplete bool           `json:"context_complete" msgpack:"context_complete"`
	Sensitivity     string         `json:"sensitivity,omitempty" msgpack:"sensitivity,omitempty"`
}
type ContentResult struct {
	Decision      string   `msgpack:"decision" json:"decision"`
	ContentDigest string   `msgpack:"content_digest" json:"content_digest"`
	Coverage      string   `msgpack:"coverage" json:"coverage"`
	Handling      string   `msgpack:"handling" json:"handling"`
	ReasonCodes   []string `msgpack:"reason_codes" json:"reason_codes"`
}
type Propose struct {
	Operation       Operation `msgpack:"operation"`
	Task            Task      `msgpack:"task"`
	JobID           string    `msgpack:"job_id"`
	Segments        []Segment `msgpack:"segments"`
	ContextComplete bool      `msgpack:"context_complete"`
	RoleID          string    `msgpack:"role_id"`
}
type Ref struct {
	InputDigest string `json:"input_digest,omitempty" msgpack:"input_digest,omitempty"`
	ID          string `json:"id" msgpack:"id"`
	Digest      string `json:"digest" msgpack:"digest"`
	Decision    string `json:"decision,omitempty" msgpack:"decision,omitempty"`
	RunID       string `json:"run_id,omitempty" msgpack:"run_id,omitempty"`
	JobID       string `json:"job_id,omitempty" msgpack:"job_id,omitempty"`
	Actor       string `json:"actor,omitempty" msgpack:"actor,omitempty"`
}
type Status struct {
	ID        string `json:"id" msgpack:"id"`
	Digest    string `json:"digest" msgpack:"digest"`
	State     string `json:"state" msgpack:"state"`
	Code      string `json:"code" msgpack:"code"`
	Expires   int64  `json:"expires" msgpack:"expires"`
	Actor     string `json:"actor" msgpack:"actor"`
	RunID     string `json:"run_id" msgpack:"run_id"`
	JobID     string `json:"job_id" msgpack:"job_id"`
	Session   string `json:"session" msgpack:"session"`
	Service   string `json:"service" msgpack:"service"`
	Action    string `json:"action" msgpack:"action"`
	InputJSON string `json:"input_json,omitempty" msgpack:"input_json,omitempty"`
}
type Execute struct {
	Approval  Ref       `msgpack:"approval"`
	Operation Operation `msgpack:"operation"`
	Session   string    `msgpack:"session"`
}
type Progress struct {
	ConversationID string `msgpack:"conversation_id"`
	State          string `msgpack:"state"`
}

func Identifier(s string) bool {
	if len(s) == 0 || len(s) > 256 || !utf8.ValidString(s) {
		return false
	}
	for _, r := range s {
		if r < 32 || r == 127 {
			return false
		}
	}
	return true
}
func Decode(raw []byte, dst any) error {
	if _, err := safevalue.ParseObject(raw); err != nil {
		return err
	}
	return protocol.DecodeRaw(raw, dst)
}
func Command(op Operation) (map[string]any, error) {
	if !safevalue.ValidName(op.Service) || !safevalue.ValidName(op.Action) {
		return nil, errors.New("INVALID_OPERATION")
	}
	m, err := safevalue.ParseObject(op.Input)
	if err != nil {
		return nil, err
	}
	return map[string]any{"kind": "service_call", "service": op.Service, "action": op.Action, "input": m}, nil
}
func Digest(actor string, p Propose) (string, error) {
	c, err := Command(p.Operation)
	if err != nil {
		return "", err
	}
	if !Identifier(p.Task.Session) || !Identifier(p.Task.Revision) || !Identifier(p.JobID) || strings.TrimSpace(p.Task.Goal) == "" {
		return "", errors.New("INVALID_TASK")
	}
	raw, err := protocol.EncodePayload(p)
	if err != nil {
		return "", err
	}
	m, err := safevalue.ParseObject(raw)
	if err != nil {
		return "", err
	}
	m["actor"] = actor
	m["version"] = Version
	m["command"] = c
	return safevalue.Digest(m), nil
}
func ContentDigest(raw []byte) (string, error) {
	m, e := safevalue.ParseObject(raw)
	if e != nil {
		return "", e
	}
	return safevalue.Digest(m), nil
}
func OperationDigest(op Operation) (string, error) {
	m, e := Command(op)
	if e != nil {
		return "", e
	}
	return safevalue.Digest(m), nil
}
func OutputAllowed(r ContentResult, digest string) bool {
	return r.Decision == "allow" && r.ContentDigest == digest && r.Coverage == "complete" && r.Handling == "continue"
}
