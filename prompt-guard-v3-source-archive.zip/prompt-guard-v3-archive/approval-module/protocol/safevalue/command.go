// Package command 解析有界 MessagePack 数据，并生成包含完整输入的稳定摘要。
package safevalue

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"sort"
	"strconv"
	"unicode/utf8"
)

const (
	MaxBytes  = 32 << 10
	MaxDepth  = 12
	MaxString = 8192
	MaxItems  = 128
	MaxNodes  = 1024
)

// Request 保留原输入，未知业务字段也参与摘要，避免核验与执行参数不一致。
type Request struct {
	Kind, Service, Action string
	Input                 map[string]any
	Digest                string
	Unsupported           bool
	Raw                   map[string]any
}

// Parse 只接受 JSON 兼容的数据，不接受扩展、二进制参数或重复键。
func Parse(raw []byte) (Request, error) {
	root, err := ParseObject(raw)
	if err != nil {
		return Request{}, err
	}
	c, ok := root["command"].(map[string]any)
	if !ok {
		return Request{}, errors.New("command 必须为对象")
	}
	return parseCommand(root, c)
}

// ParseObject 复用同一有界解码器，供独立内容接口使用；不猜测业务结构。
func ParseObject(raw []byte) (map[string]any, error) {
	if len(raw) == 0 || len(raw) > MaxBytes {
		return nil, errors.New("请求为空或超过大小上限")
	}
	d := decoder{raw: raw}
	v, err := d.value(0)
	if err != nil {
		return nil, err
	}
	if d.pos != len(raw) {
		return nil, errors.New("请求包含多余数据")
	}
	root, ok := v.(map[string]any)
	if !ok {
		return nil, errors.New("请求必须为对象")
	}
	return root, nil
}

func parseCommand(root, c map[string]any) (Request, error) {
	kind, ok := c["kind"].(string)
	if !ok || kind == "" {
		return Request{}, errors.New("command.kind 必填")
	}
	r := Request{Kind: kind, Raw: root, Digest: Digest(root)}
	r.Unsupported = unknown(root, "command", "context")
	if ctx, present := root["context"]; present {
		m, ok := ctx.(map[string]any)
		if !ok {
			return Request{}, errors.New("context 必须为对象")
		}
		r.Unsupported = r.Unsupported || unknown(m, "purpose")
		if purpose, present := m["purpose"]; present {
			if _, ok := purpose.(string); !ok {
				return Request{}, errors.New("purpose 必须为文本")
			}
		}
	}
	switch kind {
	case "service_call":
		r.Service, ok = c["service"].(string)
		if !ok || !validName(r.Service) {
			return Request{}, errors.New("service 必须为有效服务名")
		}
		r.Action, ok = c["action"].(string)
		if !ok || !validName(r.Action) {
			return Request{}, errors.New("action 必须为有效动作名")
		}
		r.Input, ok = c["input"].(map[string]any)
		if !ok {
			return Request{}, errors.New("input 必须为对象")
		}
		r.Unsupported = r.Unsupported || unknown(c, "kind", "service", "action", "input")
	case "shell":
		for _, k := range []string{"dialect", "command_text", "working_dir", "platform"} {
			if s, ok := c[k].(string); !ok || s == "" {
				return Request{}, fmt.Errorf("shell.%s 必填文本", k)
			}
		}
		r.Unsupported = r.Unsupported || unknown(c, "kind", "dialect", "command_text", "working_dir", "platform")
	default:
		// 未支持的命令类型交给策略返回正常拒绝，不猜测执行语义。
	}
	return r, nil
}

func unknown(m map[string]any, keys ...string) bool {
	for k := range m {
		found := false
		for _, allowed := range keys {
			if k == allowed {
				found = true
				break
			}
		}
		if !found {
			return true
		}
	}
	return false
}

// ValidName 限制为服务域内短名，禁止将地址冒充服务名。
func ValidName(s string) bool { return validName(s) }
func validName(s string) bool {
	if len(s) == 0 || len(s) > 64 || s[0] < 'a' || s[0] > 'z' {
		return false
	}
	for _, c := range s {
		if !((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_' || c == '-') {
			return false
		}
	}
	return true
}

// Clone 验证并深拷贝受信策略参数，保留整数精度与浮点类别。
func Clone(v any) (any, error) {
	nodes := 0
	var clone func(any, int) (any, error)
	clone = func(v any, depth int) (any, error) {
		nodes++
		if depth > MaxDepth || nodes > MaxNodes {
			return nil, errors.New("策略参数结构超过上限")
		}
		switch x := v.(type) {
		case nil, bool, int64, uint64:
			return x, nil
		case int:
			return int64(x), nil
		case float64:
			if math.IsNaN(x) || math.IsInf(x, 0) {
				return nil, errors.New("策略参数数值无效")
			}
			return x, nil
		case string:
			if len(x) > MaxString || !utf8.ValidString(x) {
				return nil, errors.New("策略参数文本无效")
			}
			return x, nil
		case []any:
			if len(x) > MaxItems {
				return nil, errors.New("策略数组过长")
			}
			out := make([]any, len(x))
			for i, val := range x {
				c, err := clone(val, depth+1)
				if err != nil {
					return nil, err
				}
				out[i] = c
			}
			return out, nil
		case map[string]any:
			if len(x) > MaxItems {
				return nil, errors.New("策略对象过大")
			}
			out := make(map[string]any, len(x))
			for key, val := range x {
				if len(key) > MaxString || !utf8.ValidString(key) {
					return nil, errors.New("策略键无效")
				}
				c, err := clone(val, depth+1)
				if err != nil {
					return nil, err
				}
				out[key] = c
			}
			return out, nil
		default:
			return nil, errors.New("策略参数类型不支持")
		}
	}
	out, err := clone(v, 0)
	if err != nil {
		return nil, err
	}
	if len(Canonical(out)) > MaxBytes {
		return nil, errors.New("策略参数超过大小上限")
	}
	return out, nil
}

// Digest 对带类型与长度的规范格式做 SHA256，保留数组顺序和浮点位语义。
func Digest(v any) string    { sum := sha256.Sum256(Canonical(v)); return hex.EncodeToString(sum[:]) }
func Canonical(v any) []byte { var b bytes.Buffer; canonical(&b, v); return b.Bytes() }
func canonical(b *bytes.Buffer, v any) {
	write := func(tag byte, text string) {
		b.WriteByte(tag)
		b.WriteString(strconv.Itoa(len(text)))
		b.WriteByte(':')
		b.WriteString(text)
	}
	switch x := v.(type) {
	case nil:
		b.WriteByte('0')
	case bool:
		if x {
			b.WriteByte('T')
		} else {
			b.WriteByte('F')
		}
	case string:
		write('s', x)
	case int64:
		write('n', strconv.FormatInt(x, 10))
	case uint64:
		write('n', strconv.FormatUint(x, 10))
	case float64:
		write('f', strconv.FormatUint(math.Float64bits(x), 16))
	case []any:
		b.WriteByte('[')
		for _, e := range x {
			canonical(b, e)
		}
		b.WriteByte(']')
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		b.WriteByte('{')
		for _, k := range keys {
			write('k', k)
			canonical(b, x[k])
		}
		b.WriteByte('}')
	default:
		panic("canonical: unsupported internal value")
	}
}

type decoder struct {
	raw        []byte
	pos, nodes int
}

func (d *decoder) take(n int) ([]byte, error) {
	if n < 0 || n > len(d.raw)-d.pos {
		return nil, errors.New("MessagePack 数据不完整")
	}
	p := d.raw[d.pos : d.pos+n]
	d.pos += n
	return p, nil
}
func (d *decoder) count(n int, isMap bool, depth int) (any, error) {
	if n > MaxItems {
		return nil, errors.New("容器元素超过上限")
	}
	if isMap {
		out := make(map[string]any, n)
		for i := 0; i < n; i++ {
			key, err := d.value(depth + 1)
			if err != nil {
				return nil, err
			}
			k, ok := key.(string)
			if !ok {
				return nil, errors.New("对象键必须为文本")
			}
			if _, exists := out[k]; exists {
				return nil, errors.New("对象包含重复键")
			}
			val, err := d.value(depth + 1)
			if err != nil {
				return nil, err
			}
			out[k] = val
		}
		return out, nil
	}
	out := make([]any, n)
	for i := range out {
		val, err := d.value(depth + 1)
		if err != nil {
			return nil, err
		}
		out[i] = val
	}
	return out, nil
}
func (d *decoder) str(n int) (any, error) {
	if n > MaxString {
		return nil, errors.New("文本超过上限")
	}
	p, err := d.take(n)
	if err != nil {
		return nil, err
	}
	if !utf8.Valid(p) {
		return nil, errors.New("文本不是有效 UTF-8")
	}
	return string(p), nil
}
func (d *decoder) value(depth int) (any, error) {
	d.nodes++
	if depth > MaxDepth || d.nodes > MaxNodes {
		return nil, errors.New("请求嵌套或节点超过上限")
	}
	p, err := d.take(1)
	if err != nil {
		return nil, err
	}
	c := p[0]
	switch {
	case c <= 0x7f:
		return uint64(c), nil
	case c >= 0xe0:
		return int64(int8(c)), nil
	case c >= 0xa0 && c <= 0xbf:
		return d.str(int(c & 31))
	case c >= 0x80 && c <= 0x8f:
		return d.count(int(c&15), true, depth)
	case c >= 0x90 && c <= 0x9f:
		return d.count(int(c&15), false, depth)
	}
	if c == 0xc0 {
		return nil, nil
	}
	if c == 0xc2 {
		return false, nil
	}
	if c == 0xc3 {
		return true, nil
	}
	width := 0
	switch c {
	case 0xcc, 0xd0, 0xd9:
		width = 1
	case 0xcd, 0xd1, 0xda, 0xdc, 0xde:
		width = 2
	case 0xce, 0xd2, 0xca, 0xdb, 0xdd, 0xdf:
		width = 4
	case 0xcf, 0xd3, 0xcb:
		width = 8
	default:
		return nil, errors.New("不支持的 MessagePack 类型")
	}
	p, err = d.take(width)
	if err != nil {
		return nil, err
	}
	var n uint64
	switch width {
	case 1:
		n = uint64(p[0])
	case 2:
		n = uint64(binary.BigEndian.Uint16(p))
	case 4:
		n = uint64(binary.BigEndian.Uint32(p))
	case 8:
		n = binary.BigEndian.Uint64(p)
	}
	switch c {
	case 0xcc, 0xcd, 0xce, 0xcf:
		return n, nil
	case 0xd0:
		return int64(int8(n)), nil
	case 0xd1:
		return int64(int16(n)), nil
	case 0xd2:
		return int64(int32(n)), nil
	case 0xd3:
		return int64(n), nil
	case 0xca, 0xcb:
		var f float64
		if c == 0xca {
			f = float64(math.Float32frombits(uint32(n)))
		} else {
			f = math.Float64frombits(n)
		}
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, errors.New("不接受非有限数值")
		}
		return f, nil
	case 0xd9, 0xda, 0xdb:
		if n > MaxString {
			return nil, errors.New("文本超过上限")
		}
		return d.str(int(n))
	case 0xdc, 0xdd, 0xde, 0xdf:
		if n > MaxItems {
			return nil, errors.New("容器元素超过上限")
		}
		return d.count(int(n), c == 0xde || c == 0xdf, depth)
	}
	return nil, errors.New("未知编码")
}
