package safevalue

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"strconv"
	"strings"
)

// ParseJSON 与 WS 入口使用相同的资源边界；拒绝重复字段，保留整数精度。
func ParseJSON(data []byte) (any, error) {
	if len(data) == 0 || len(data) > MaxBytes {
		return nil, errors.New("JSON 为空或超过 32 KiB")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	d.UseNumber()
	nodes := 0
	var read func(int) (any, error)
	read = func(depth int) (any, error) {
		nodes++
		if depth > MaxDepth || nodes > MaxNodes {
			return nil, errors.New("JSON 结构超过上限")
		}
		token, err := d.Token()
		if err != nil {
			return nil, errors.New("JSON 格式错误")
		}
		if delim, ok := token.(json.Delim); ok {
			switch delim {
			case '{':
				m := map[string]any{}
				for d.More() {
					key, err := d.Token()
					if err != nil {
						return nil, err
					}
					k, ok := key.(string)
					if !ok {
						return nil, errors.New("对象键无效")
					}
					if _, exists := m[k]; exists {
						return nil, errors.New("JSON 包含重复键")
					}
					if len(m) >= MaxItems {
						return nil, errors.New("对象过大")
					}
					v, err := read(depth + 1)
					if err != nil {
						return nil, err
					}
					m[k] = v
				}
				end, err := d.Token()
				if err != nil || end != json.Delim('}') {
					return nil, errors.New("对象不完整")
				}
				return m, nil
			case '[':
				a := []any{}
				for d.More() {
					if len(a) >= MaxItems {
						return nil, errors.New("数组过大")
					}
					v, err := read(depth + 1)
					if err != nil {
						return nil, err
					}
					a = append(a, v)
				}
				end, err := d.Token()
				if err != nil || end != json.Delim(']') {
					return nil, errors.New("数组不完整")
				}
				return a, nil
			default:
				return nil, errors.New("JSON 结构错误")
			}
		}
		if n, ok := token.(json.Number); ok {
			if i, err := strconv.ParseInt(string(n), 10, 64); err == nil {
				return i, nil
			}
			if u, err := strconv.ParseUint(string(n), 10, 64); err == nil {
				return u, nil
			}
			if !strings.ContainsAny(string(n), ".eE") {
				return nil, errors.New("整数超出支持范围")
			}
			f, err := strconv.ParseFloat(string(n), 64)
			if err != nil {
				return nil, errors.New("数值无效")
			}
			return f, nil
		}
		return token, nil
	}
	v, err := read(0)
	if err != nil {
		return nil, err
	}
	if _, err = d.Token(); err != io.EOF {
		return nil, errors.New("JSON 包含多余内容")
	}
	return Clone(v)
}

// DecodeStrictObject 用于本地配置及模型结果，拒绝重复键、多余字段与尾随数据。
func DecodeStrictObject(data []byte, dst any) error {
	v, err := ParseJSON(data)
	if err != nil {
		return err
	}
	if _, ok := v.(map[string]any); !ok {
		return errors.New("JSON 必须为对象")
	}
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.UseNumber()
	d.DisallowUnknownFields()
	return d.Decode(dst)
}
