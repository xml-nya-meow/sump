param([switch]$Test)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$taskSDK=Join-Path $taskRoot '../../SUMP-security-result/.tools/go/bin/go.exe'
$taskGo=$env:SUMP_GO_EXE
if(-not $taskGo -and (Test-Path -LiteralPath $taskSDK)){$taskGo=(Resolve-Path -LiteralPath $taskSDK).Path}
if(-not $taskGo){$taskCmd=Get-Command go -ErrorAction SilentlyContinue;if($taskCmd){$taskGo=$taskCmd.Source}}
if(-not $taskGo){throw 'Go 1.26 is required to build source. Precompiled bin files can run without Go.'}
$env:GOTOOLCHAIN='local'
$taskBuilds=@(@('security','sump-security'),@('settings-center','sump-center'),@('security/cmd/console','sump-console'),@('security/cmd/launcher','sump-launcher'),@('security/cmd/check','sump-check'),@('security/cmd/review','sump-review'))
if(Test-Path -LiteralPath (Join-Path $taskRoot 'reasoner')){$taskBuilds+=,@('reasoner','sump-reasoner');$taskBuilds+=,@('memory','sump-memory');$taskBuilds+=,@('qq','sump-qq');$taskBuilds+=,@('images','sump-images')}
if($Test){
 $taskModules=@('protocol','security','service','settings-center')
 if(Test-Path -LiteralPath (Join-Path $taskRoot 'memory')){$taskModules+='memory'}
 foreach($taskModule in $taskModules){& $taskGo -C (Join-Path $taskRoot $taskModule) test ./...;if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}}
}else{
 New-Item -ItemType Directory -Force -Path (Join-Path $taskRoot 'bin')|Out-Null
 foreach($taskBuild in $taskBuilds){& $taskGo -C (Join-Path $taskRoot $taskBuild[0]) build -trimpath -o (Join-Path $taskRoot ('bin/'+$taskBuild[1]+'.exe')) .;if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}}
}
