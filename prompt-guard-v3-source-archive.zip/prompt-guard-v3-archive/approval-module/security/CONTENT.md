# 内容核验接口（v3）

语义评估模块沿用上一版分层设计，本次加入整体敏感度策略与核心执行/输出适配。已通过本地模拟模型管道联调；真实模型语义效果尚未评估。

请求样例见 `examples/output-buffer.json`。完整字段：stage、task(goal/session/revision)、role_id、segments(id/source/text/sensitivity/language_hint?)、context_complete、整体 sensitivity，以及按 stage 提供的 candidate 或 command。

- stage 可为 input/context/action/output/memory。action 必须有 command；output/memory 必须有 candidate。
- session/revision 是 1~256 字节有效 UTF-8 标识，允许冒号，拒绝控制字符；不能作为调用身份。
- source 为 user/file/web/tool/memory/assistant/unknown，不产生权限升级；最多 16 段。
- role_id 只引用可信本地 roles；集成核心固定使用 general。附件、语言提示和模型正文均不能注入新角色政策。
- 单字符串最多 8192 UTF-8 字节，请求最多 32 KiB、深度 12、容器 128 元素、总节点 1024；拒绝重复键、非有限数和不合法结构。
- context_complete 必须反映实际覆盖，缺失或超限不会静默当作完整。
- 整体 sensitivity 覆盖任务、命令、候选内容；段落各自也须通过 allowed_sensitivities。缺失整体标签按 unknown，默认只允许 public；本地示例可显式准许 private/unknown，secret 不提交。程序无法自动保证标签准确。

结果：decision=allow/require_approval/deny；coverage=complete/boundary_only/insufficient/unavailable；handling=continue/data_only/hold/quarantine/regenerate。完整覆盖指本次有界包，不指整个未来会话安全。deny 可能只是模型不可用，不能直接解释成恶意内容。

语义模型使用固定审查规则、独立结构化结果，不具备工具或审批权限。待审内容作为数据消息；规则明确正常模板分析、多语言、引用或角色扮演不单独构成攻击。风险类别包括伪造授权、指令越权、任务转移、泄露、未授权动作、记忆污染、角色偏离。理解不足必须返回不足，不靠扩充各语言关键词。

data_only 快速路径默认关闭，且不能用于执行和最终输出。可选 fast_model 初筛安全且完整才结束，否则复核，受同一内容总预算约束；普通配置留空以只调用一次模型。没有语义缓存，没有后台目录/网页扫描。

review_content 自身仍返回 assessment_mode=advisory、execution_authorization=none：它给评估，不给批准。创建真实审批请调用 approval_request；最终输出的强制阻断由核心适配执行。完整流程和能力边界见上级《功能与使用说明.md》与《接入契约.md》。
