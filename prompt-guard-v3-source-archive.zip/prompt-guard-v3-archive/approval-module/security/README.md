# security 审批核验模块 · 交付 v3

功能本体在此目录；通过父目录 go.work 使用 protocol、service 的共同协议与服务骨架。

`check` 和 `review_content` 是咨询评估；`approval_*` 构成认证审批控制面；真正执行在业务服务。本版首个接入动作 memory.remember。所有核验/审批接口均 tool:false，模型不能自行批准。

- `command/`：共用安全解码器的兼容出口。
- `policy/`：本地可信动作策略（记忆优先级沿用核心整数合同，核验范围 -1000000~1000000）。
- `review/`：有界多语言内容评估。
- `approval/`：时效、取消、摘要绑定和单次领取。
- `audit/`：单写入者、有界队列、同步审计。
- `server/`：协议适配和自身故障分类。
- `cmd/console`、`cmd/launcher`：网页与启动器。
- `buffer/`：上一版可复用缓冲组件；核心强制适配在 reasoner/server/guard.go。

运行请用父目录启动.cmd，配置见父目录使用说明。旧 cmd/check 与 cmd/review 客户端源码/二进制保留用于旧咨询开发，未带本版身份签名，不能直接连接默认受保护实例；新用户使用网页。

内容协议见 [CONTENT.md](CONTENT.md)，整体协议见 [../接入契约.md](../接入契约.md)。编译产物已生成，模块测试与本地模拟联调通过；真实模型尚未运行。
