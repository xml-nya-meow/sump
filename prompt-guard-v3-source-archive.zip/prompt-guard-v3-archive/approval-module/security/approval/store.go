// Package approval owns bounded, process-lifetime approvals. Restart invalidates all grants.
package approval

import (
	"context"
	"encoding/json"
	"errors"
	"sort"
	"sync"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/protocol/safevalue"
	"github.com/QAQ-awa-QAQ/sump/security/audit"
)

type Entry struct {
	Status   guard.Status
	Proposal guard.Propose
	Policy   string
}
type Store struct {
	mu      sync.Mutex
	entries map[string]*Entry
	audit   audit.Sink
	ttl     time.Duration
}

var ErrStore = errors.New("APPROVAL_STORE_FAILURE")

func New(sink audit.Sink, ttl time.Duration) *Store {
	if ttl <= 0 || ttl > 10*time.Minute {
		ttl = 5 * time.Minute
	}
	return &Store{entries: map[string]*Entry{}, audit: sink, ttl: ttl}
}
func (s *Store) transition(ctx context.Context, e *Entry, state string) error {
	if err := s.audit.Record(ctx, audit.Record{At: time.Now().UTC(), Action: "approval_" + state, Decision: state, PolicyVersion: e.Policy, CommandDigest: e.Status.Digest, ReasonCodes: []string{"APPROVAL_STATE"}}); err != nil {
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if errors.Is(err, audit.ErrBusy) {
			return err
		}
		return ErrStore
	}
	if ctx.Err() != nil {
		return ctx.Err()
	}
	e.Status.State = state
	return nil
}
func (s *Store) Create(ctx context.Context, actor string, p guard.Propose, policy string) (guard.Status, error) {
	digest, err := guard.Digest(actor, p)
	if err != nil {
		return guard.Status{}, err
	}
	raw, err := protocol.EncodePayload(p)
	if err != nil {
		return guard.Status{}, err
	}
	var frozen guard.Propose
	if guard.Decode(raw, &frozen) != nil {
		return guard.Status{}, errors.New("INVALID_REQUEST")
	}
	input, err := safevalue.ParseObject(frozen.Operation.Input)
	if err != nil {
		return guard.Status{}, err
	}
	preview, err := json.MarshalIndent(input, "", "  ")
	if err != nil {
		return guard.Status{}, err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	now := time.Now().Unix()
	for id, e := range s.entries {
		if e.Status.Expires+60 < now {
			delete(s.entries, id)
		}
	}
	for _, e := range s.entries {
		if e.Status.Actor == actor && e.Status.RunID == p.Task.Revision && e.Status.JobID == p.JobID {
			if e.Status.Digest != digest {
				return guard.Status{}, errors.New("JOB_CHANGED")
			}
			return e.Status, nil
		}
	}
	if len(s.entries) >= 256 {
		return guard.Status{}, errors.New("APPROVAL_BUSY")
	}
	e := &Entry{Proposal: frozen, Policy: policy, Status: guard.Status{ID: protocol.NewID(), Digest: digest, Code: "HUMAN_APPROVAL_REQUIRED", Expires: time.Now().Add(s.ttl).Unix(), Actor: actor, RunID: p.Task.Revision, JobID: p.JobID, Session: p.Task.Session, Service: p.Operation.Service, Action: p.Operation.Action, InputJSON: string(preview)}}
	if err = s.transition(ctx, e, "pending"); err != nil {
		return guard.Status{}, err
	}
	s.entries[e.Status.ID] = e
	return e.Status, nil
}
func (s *Store) access(ctx context.Context, ref guard.Ref, actor string, operator bool) (*Entry, error) {
	e := s.entries[ref.ID]
	if e == nil {
		return nil, errors.New("APPROVAL_NOT_FOUND_OR_RESTARTED")
	}
	if !operator && e.Status.Actor != actor {
		return nil, errors.New("APPROVAL_FORBIDDEN")
	}
	if e.Status.Expires <= time.Now().Unix() && (e.Status.State == "pending" || e.Status.State == "approved") {
		if err := s.transition(ctx, e, "expired"); err != nil {
			return nil, err
		}
	}
	if ref.Digest != "" && ref.Digest != e.Status.Digest {
		return nil, errors.New("APPROVAL_DIGEST_MISMATCH")
	}
	return e, nil
}
func (s *Store) Status(ctx context.Context, ref guard.Ref, actor string, operator bool) (guard.Status, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, err := s.access(ctx, ref, actor, operator)
	if err != nil {
		return guard.Status{}, err
	}
	return e.Status, nil
}
func (s *Store) Decide(ctx context.Context, ref guard.Ref) (guard.Status, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, err := s.access(ctx, ref, "", true)
	if err != nil {
		return guard.Status{}, err
	}
	if ref.Digest == "" || (ref.Decision != "approved" && ref.Decision != "denied") {
		return guard.Status{}, errors.New("INVALID_DECISION")
	}
	if e.Status.State == ref.Decision {
		return e.Status, nil
	}
	if e.Status.State != "pending" {
		return guard.Status{}, errors.New("APPROVAL_NOT_PENDING")
	}
	if err = s.transition(ctx, e, ref.Decision); err != nil {
		return guard.Status{}, err
	}
	return e.Status, nil
}
func (s *Store) Cancel(ctx context.Context, actor, run string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, e := range s.entries {
		if e.Status.Actor == actor && e.Status.RunID == run && (e.Status.State == "pending" || e.Status.State == "approved") {
			if err := s.transition(ctx, e, "cancelled"); err != nil {
				return err
			}
		}
	}
	return nil
}

// Consume atomically binds the single execution attempt to the authenticated target service.
func (s *Store) Consume(ctx context.Context, ref guard.Ref, target string) (guard.Status, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, err := s.access(ctx, ref, ref.Actor, false)
	if err != nil {
		return guard.Status{}, err
	}
	if ref.Digest == "" || ref.RunID != e.Status.RunID || ref.JobID != e.Status.JobID || target != e.Status.Service {
		return guard.Status{}, errors.New("EXECUTION_MISMATCH")
	}
	expected, err := guard.OperationDigest(e.Proposal.Operation)
	if err != nil || expected != ref.InputDigest {
		return guard.Status{}, errors.New("EXECUTION_PARAMETERS_CHANGED")
	}
	if e.Status.State != "approved" {
		return e.Status, nil
	}
	if err = s.transition(ctx, e, "consumed"); err != nil {
		return guard.Status{}, err
	}
	out := e.Status
	out.Code = "EXECUTION_CLAIMED"
	return out, nil
}
func (s *Store) List() []guard.Status {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := []guard.Status{}
	for _, e := range s.entries {
		x := e.Status
		x.InputJSON = ""
		if x.Expires <= time.Now().Unix() && (x.State == "pending" || x.State == "approved") {
			x.State = "expired"
		}
		out = append(out, x)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID > out[j].ID })
	return out
}
