package approval

import (
 "context"
 "errors"
 "testing"
 "time"
 "github.com/QAQ-awa-QAQ/sump/protocol"
 "github.com/QAQ-awa-QAQ/sump/protocol/guard"
 "github.com/QAQ-awa-QAQ/sump/security/audit"
)

type testAudit struct{fail bool}
func(a *testAudit)Record(context.Context,audit.Record)error{if a.fail{return errors.New("disk failure")};return nil}
func proposal(t *testing.T)guard.Propose{
 t.Helper();raw,e:=protocol.EncodePayload(map[string]any{"kind":"preference","content":"tea","priority":1,"conversation_id":"qq:private:123"});if e!=nil{t.Fatal(e)}
 return guard.Propose{Operation:guard.Operation{Service:"memory",Action:"remember",Input:raw},Task:guard.Task{Goal:"remember preference",Session:"qq:private:123",Revision:"run-1"},JobID:"job-1",RoleID:"general",ContextComplete:true}
}
func TestGrantExactBindingSingleConsumeAndCancellation(t *testing.T){
 ctx:=context.Background();a:=&testAudit{};s:=New(a,time.Minute);p:=proposal(t)
 x,e:=s.Create(ctx,"reasoner",p,"test");if e!=nil{t.Fatal(e)}
 input,_:=guard.OperationDigest(p.Operation)
 ref:=guard.Ref{ID:x.ID,Digest:x.Digest,Actor:"reasoner",RunID:p.Task.Revision,JobID:p.JobID,InputDigest:input,Decision:"approved"}
 bad:=ref;bad.Digest="changed";if _,e=s.Decide(ctx,bad);e==nil{t.Fatal("changed approval allowed")}
 if _,e=s.Decide(ctx,ref);e!=nil{t.Fatal(e)}
 bad=ref;bad.InputDigest="changed";if _,e=s.Consume(ctx,bad,"memory");e==nil{t.Fatal("changed operation allowed")}
 if _,e=s.Consume(ctx,ref,"qq");e==nil{t.Fatal("wrong executor allowed")}
 x,e=s.Consume(ctx,ref,"memory");if e!=nil||x.Code!="EXECUTION_CLAIMED"{t.Fatalf("%+v %v",x,e)}
 x,e=s.Consume(ctx,ref,"memory");if e!=nil||x.Code=="EXECUTION_CLAIMED"{t.Fatalf("repeat grant: %+v %v",x,e)}
 p.Task.Revision="run-2";x,e=s.Create(ctx,"reasoner",p,"test");if e!=nil{t.Fatal(e)}
 if e=s.Cancel(ctx,"reasoner","run-2");e!=nil{t.Fatal(e)}
 if _,e=s.Decide(ctx,guard.Ref{ID:x.ID,Digest:x.Digest,Decision:"approved"});e==nil{t.Fatal("cancelled task approved")}
}
func TestAuditFailureDoesNotPublishPendingGrant(t *testing.T){
 s:=New(&testAudit{fail:true},time.Minute)
 if _,e:=s.Create(context.Background(),"reasoner",proposal(t),"test");!errors.Is(e,ErrStore){t.Fatalf("unexpected error %v",e)}
 if len(s.List())!=0{t.Fatal("unaudited grant published")}
}
