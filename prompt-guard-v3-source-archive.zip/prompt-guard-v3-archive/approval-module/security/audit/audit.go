// Package audit 保存最小脱敏审计；不保存命令、参数、会话或身份自述。
package audit

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sync"
	"time"
)

var ErrBusy = errors.New("AUDIT_BUSY")

type Record struct {
	At             time.Time `json:"at"`
	Decision       string    `json:"decision"`
	PolicyVersion  string    `json:"policy_version"`
	CommandDigest  string    `json:"command_digest,omitempty"`
	Action         string    `json:"action,omitempty"`
	ContentDigest  string    `json:"content_digest,omitempty"`
	Coverage       string    `json:"coverage,omitempty"`
	AnalyzerStatus string    `json:"analyzer_status,omitempty"`
	ReasonCodes    []string  `json:"reason_codes"`
}
type Sink interface {
	Record(context.Context, Record) error
}
type writeJob struct {
	ctx    context.Context
	data   []byte
	result chan error
}
type File struct {
	file     *os.File
	jobs     chan writeJob
	stop     chan struct{}
	done     chan struct{}
	once     sync.Once
	closeErr error
}

// Open starts one bounded durable writer. Cancellation never creates another writer.
func Open(path string) (*File, error) {
	if path == "" {
		return nil, errors.New("audit path empty")
	}
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return nil, err
	}
	sink := &File{file: f, jobs: make(chan writeJob, 32), stop: make(chan struct{}), done: make(chan struct{})}
	go sink.run()
	return sink, nil
}
func (f *File) run() {
	defer close(f.done)
	defer func() { f.closeErr = f.file.Close() }()
	failed := false
	for {
		select {
		case <-f.stop:
			return
		case job := <-f.jobs:
			if job.ctx.Err() != nil {
				job.result <- job.ctx.Err()
				continue
			}
			if failed {
				job.result <- errors.New("audit unavailable")
				continue
			}
			n, err := f.file.Write(job.data)
			if err == nil && n != len(job.data) {
				err = errors.New("audit short write")
			}
			if err == nil {
				err = f.file.Sync()
			}
			if err != nil {
				failed = true
			}
			job.result <- err
		}
	}
}
func (f *File) Record(ctx context.Context, r Record) error {
	if ctx.Err() != nil {
		return ctx.Err()
	}
	b, err := json.Marshal(r)
	if err != nil {
		return err
	}
	job := writeJob{ctx: ctx, data: append(b, '\n'), result: make(chan error, 1)}
	select {
	case <-f.stop:
		return errors.New("audit closed")
	default:
	}
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-f.stop:
		return errors.New("audit closed")
	case f.jobs <- job:
	default:
		return ErrBusy
	}
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-f.stop:
		return errors.New("audit closed")
	case err := <-job.result:
		if ctx.Err() != nil {
			return ctx.Err()
		}
		return err
	}
}
func (f *File) Close() error { f.once.Do(func() { close(f.stop) }); <-f.done; return f.closeErr }
