package audit_test

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/QAQ-awa-QAQ/sump/security/audit"
)

func TestAppendAndClosedFailure(t *testing.T) {
	path := filepath.Join(t.TempDir(), "audit.jsonl")
	sink, err := audit.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	r := audit.Record{At: time.Now().UTC(), Decision: "deny", CommandDigest: strings.Repeat("a", 64), PolicyVersion: "v1", ReasonCodes: []string{"POLICY_DENY"}}
	if err := sink.Record(context.Background(), r); err != nil {
		t.Fatal(err)
	}
	if err := sink.Close(); err != nil {
		t.Fatal(err)
	}
	if err := sink.Record(context.Background(), r); err == nil {
		t.Fatal("已关闭审计必须失败")
	}
	b, err := os.ReadFile(path)
	if err != nil || strings.Count(string(b), "\n") != 1 {
		t.Fatal("应只有一条已持久化记录")
	}
}
