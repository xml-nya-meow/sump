// Package buffer 是输出/记忆交付方使用的整条缓冲组件，不是中央消息转发器。
package buffer

import (
	"context"
	"errors"
	"sync"
	"unicode/utf8"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/command"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
	"github.com/QAQ-awa-QAQ/sump/security/review"
)

var ErrHeld = errors.New("内容未获放行，缓冲内容未交付")
var ErrClosed = errors.New("缓冲已结束")

type ReviewFunc func(context.Context, []byte) (review.Result, error)
type DeliverFunc func(context.Context, string) error
type Buffer struct {
	mu       sync.Mutex
	metadata map[string]any
	data     []byte
	closed   bool
}

// New 接受不含 candidate 的 MessagePack 元数据；复制并验证，避免后来换任务。
func New(metadata []byte) (*Buffer, error) {
	m, err := command.ParseObject(metadata)
	if err != nil {
		return nil, err
	}
	if _, exists := m["candidate"]; exists {
		return nil, errors.New("候选内容应由缓冲收集")
	}
	stage, _ := m["stage"].(string)
	if stage != "output" && stage != "memory" {
		return nil, errors.New("缓冲只用于 output 或 memory")
	}
	m["candidate"] = "pending"
	raw, err := protocol.EncodePayload(m)
	if err != nil {
		return nil, err
	}
	if _, err := review.Parse(raw); err != nil {
		return nil, err
	}
	delete(m, "candidate")
	return &Buffer{metadata: m}, nil
}

// Write 接受生成分片但不发送；字节上限与内容接口单字符串上限一致。
func (b *Buffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed {
		return 0, ErrClosed
	}
	if len(p) > command.MaxString-len(b.data) {
		b.discard()
		return 0, errors.New("整条缓冲超过 8192 字节")
	}
	b.data = append(b.data, p...)
	return len(p), nil
}

func (b *Buffer) discard() {
	for i := range b.data {
		b.data[i] = 0
	}
	b.data = nil
	b.metadata = nil
	b.closed = true
}
func (b *Buffer) Discard() { b.mu.Lock(); defer b.mu.Unlock(); b.discard() }

// Release 只有完整绑定的 allow/complete 才调用交付函数，且每个缓冲仅一次。
// 回调应使用带必需审计的服务接口；调用者另行验证真实接收者/存储权限。
func (b *Buffer) Release(ctx context.Context, assess ReviewFunc, deliver DeliverFunc) (review.Result, error) {
	if assess == nil || deliver == nil {
		b.Discard()
		return review.Result{}, errors.New("核验及交付函数不可缺失")
	}
	b.mu.Lock()
	if b.closed {
		b.mu.Unlock()
		return review.Result{}, ErrClosed
	}
	if !utf8.Valid(b.data) || len(b.data) == 0 {
		b.discard()
		b.mu.Unlock()
		return review.Result{}, errors.New("缓冲为空或不是完整 UTF-8")
	}
	text := string(b.data)
	m := b.metadata
	m["candidate"] = text
	raw, err := protocol.EncodePayload(m)
	b.discard()
	b.mu.Unlock()
	if err != nil {
		return review.Result{}, err
	}
	r, err := review.Parse(raw)
	if err != nil {
		return review.Result{}, err
	}
	if err := ctx.Err(); err != nil {
		return review.Result{}, err
	}
	x, err := assess(ctx, append([]byte(nil), raw...))
	if err != nil {
		return x, err
	}
	if !review.ValidResult(x, r) || x.Decision != policy.Allow || x.Coverage != "complete" || x.Handling != "continue" {
		return x, ErrHeld
	}
	if err := ctx.Err(); err != nil {
		return x, err
	}
	return x, deliver(ctx, text)
}
