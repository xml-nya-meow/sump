package buffer

import (
	"context"
	"errors"
	"testing"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
	"github.com/QAQ-awa-QAQ/sump/security/review"
)

func pending(t *testing.T) *Buffer {
	t.Helper()
	raw, err := protocol.EncodePayload(map[string]any{"stage": "output", "task": map[string]any{"goal": "欢迎用户", "session": "test", "revision": "turn-one"}, "role_id": "general", "segments": []any{}, "context_complete": true})
	if err != nil {
		t.Fatal(err)
	}
	b, err := New(raw)
	if err != nil {
		t.Fatal(err)
	}
	return b
}
func answer(t *testing.T, raw []byte, decision, coverage string) review.Result {
	t.Helper()
	r, err := review.Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	handling := "hold"
	risk := "unknown"
	if decision == policy.Allow {
		handling = "continue"
		risk = "low"
	}
	return review.Result{Decision: decision, RiskLevel: risk, ReasonCodes: []string{"TEST"}, Reasons: []string{"test"}, PolicyVersion: "test", ContentDigest: r.Digest, AssessmentMode: "advisory", Coverage: coverage, Handling: handling, AnalyzerStatus: "complete", Findings: []review.Finding{}, SourceTrust: "unverified", ExecutionAuthorization: "none", Limitations: []string{"test"}}
}
func TestHeldBufferNeverCallsDelivery(t *testing.T) {
	b := pending(t)
	_, _ = b.Write([]byte("pending private text"))
	calls := 0
	_, err := b.Release(context.Background(), func(_ context.Context, raw []byte) (review.Result, error) {
		return answer(t, raw, policy.Deny, "insufficient"), nil
	}, func(context.Context, string) error { calls++; return nil })
	if !errors.Is(err, ErrHeld) || calls != 0 {
		t.Fatalf("delivery happened: calls=%d error=%v", calls, err)
	}
}
func TestCompleteBoundResultReleasesOnce(t *testing.T) {
	b := pending(t)
	_, _ = b.Write([]byte("Bonjour !"))
	calls := 0
	assess := func(_ context.Context, raw []byte) (review.Result, error) {
		return answer(t, raw, policy.Allow, "complete"), nil
	}
	deliver := func(_ context.Context, s string) error {
		if s != "Bonjour !" {
			t.Fatal("wrong candidate")
		}
		calls++
		return nil
	}
	if _, err := b.Release(context.Background(), assess, deliver); err != nil {
		t.Fatal(err)
	}
	if _, err := b.Release(context.Background(), assess, deliver); !errors.Is(err, ErrClosed) {
		t.Fatal("buffer released twice")
	}
	if calls != 1 {
		t.Fatal("unexpected number of deliveries")
	}
}
func TestAllowWithWrongDigestCannotRelease(t *testing.T) {
	b := pending(t)
	_, _ = b.Write([]byte("candidate"))
	calls := 0
	_, err := b.Release(context.Background(), func(_ context.Context, raw []byte) (review.Result, error) {
		x := answer(t, raw, policy.Allow, "complete")
		x.ContentDigest = "wrong"
		return x, nil
	}, func(context.Context, string) error { calls++; return nil })
	if !errors.Is(err, ErrHeld) || calls != 0 {
		t.Fatal("unbound result released")
	}
}
