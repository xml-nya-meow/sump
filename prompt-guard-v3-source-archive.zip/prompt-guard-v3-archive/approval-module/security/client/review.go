// Package client 调用独立的内容接口，校验结论与原始请求摘要的绑定。
package client

import (
	"context"
	"errors"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/review"
)

func Review(ctx context.Context, addr string, raw []byte) (review.Result, error) {
	raw = append([]byte(nil), raw...)
	r, err := review.Parse(raw)
	if err != nil {
		return review.Result{}, err
	}
	c, err := protocol.DialContext(ctx, addr, nil)
	if err != nil {
		return review.Result{}, errors.New("无法连接内容核验服务")
	}
	defer c.Close()
	env, err := protocol.NewEnvelope(protocol.TypeJump, "security-review", "security", "", protocol.JumpPayload{Action: "review_content", Input: raw})
	if err != nil {
		return review.Result{}, errors.New("内容请求无法封装")
	}
	response, err := c.Call(ctx, env)
	if err != nil {
		return review.Result{}, errors.New("内容核验取消、超时或连接中断；未放行")
	}
	var payload protocol.ResponsePayload
	if response.DecodePayload(&payload) != nil {
		return review.Result{}, errors.New("内容响应无效")
	}
	if !payload.OK {
		return review.Result{}, errors.New("内容核验未完成；查看服务本地脱敏状态")
	}
	var x review.Result
	if protocol.DecodeRaw(payload.Data, &x) != nil || !review.ValidResult(x, r) {
		return review.Result{}, errors.New("内容结果无效或摘要不匹配")
	}
	return x, nil
}
