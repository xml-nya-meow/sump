// check 是手动测试客户端：只发送核验请求，不执行待核验命令。
package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/client"
	"github.com/QAQ-awa-QAQ/sump/security/command"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
)

func main() {
	addr := flag.String("addr", "ws://127.0.0.1:9501/ws", "security WS 地址")
	example := flag.String("example", "", "ping / remember / unknown / shell")
	requestFile := flag.String("request", "", "自定义请求 JSON 文件")
	flag.Parse()
	if *example != "" && *requestFile != "" {
		fmt.Fprintln(os.Stderr, "example 与 request 不能同时使用")
		os.Exit(1)
	}
	if *example != "" {
		request, err := exampleRequest(*example)
		if err == nil {
			err = submit(*addr, request, os.Stdout)
		}
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if *requestFile != "" {
		file, err := os.Open(*requestFile)
		if err != nil {
			fmt.Fprintln(os.Stderr, "无法打开请求文件")
			os.Exit(1)
		}
		defer file.Close()
		data, err := io.ReadAll(io.LimitReader(file, command.MaxBytes+1))
		if err == nil {
			var request any
			request, err = parseJSON(data)
			if err == nil {
				err = submit(*addr, request, os.Stdout)
			}
		}
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	if err := Interactive(*addr, os.Stdin, os.Stdout); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

// Interactive 是用户主动选择的四个示例与自定义请求入口。
func Interactive(addr string, reader io.Reader, writer io.Writer) error {
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 1024), command.MaxBytes+1)
	for {
		fmt.Fprintln(writer, "\nSUMP 安全核验测试（咨询模式，不执行命令）")
		fmt.Fprintln(writer, "1 连通性查询（预期 allow）\n2 写记忆（预期 require_approval）\n3 未知动作（预期 deny）\n4 Shell（预期 deny）\n5 输入一行自定义命令 JSON\n6 核验指定内容请求 JSON 文件\n0 退出")
		fmt.Fprint(writer, "请选择：")
		if !scanner.Scan() {
			return scanner.Err()
		}
		choice := strings.TrimSpace(scanner.Text())
		if choice == "0" {
			return nil
		}
		var request any
		var err error
		switch choice {
		case "1":
			request, err = exampleRequest("ping")
		case "2":
			request, err = exampleRequest("remember")
		case "3":
			request, err = exampleRequest("unknown")
		case "4":
			request, err = exampleRequest("shell")
		case "5":
			fmt.Fprintln(writer, `示例：{"command":{"kind":"service_call","service":"settings-center","action":"ping","input":{}}}`)
			fmt.Fprint(writer, "请求 JSON：")
			if !scanner.Scan() {
				return scanner.Err()
			}
			request, err = parseJSON([]byte(scanner.Text()))
		case "6":
			fmt.Fprint(writer, "内容请求文件路径（UTF-8 JSON）：")
			if !scanner.Scan() {
				return scanner.Err()
			}
			path := strings.Trim(strings.TrimSpace(scanner.Text()), "\"")
			file, openErr := os.Open(path)
			if openErr != nil {
				fmt.Fprintln(writer, "无法打开指定文件")
				continue
			}
			data, readErr := io.ReadAll(io.LimitReader(file, command.MaxBytes+1))
			_ = file.Close()
			if readErr == nil {
				err = submitContent(addr, data, writer)
			} else {
				err = errors.New("文件读取失败")
			}
			if err != nil {
				fmt.Fprintln(writer, "本次内容核验未完成：", err)
			}
			continue
		default:
			fmt.Fprintln(writer, "请选择 0 至 6")
			continue
		}
		if err == nil {
			err = submit(addr, request, writer)
		}
		if err != nil {
			fmt.Fprintln(writer, "本次请求失败：", err)
		}
	}
}

func submitContent(addr string, data []byte, writer io.Writer) error {
	v, err := command.ParseJSON(data)
	if err != nil {
		return err
	}
	raw, err := protocol.EncodePayload(v)
	if err != nil {
		return errors.New("请求不能编码")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	x, err := client.Review(ctx, addr, raw)
	if err != nil {
		return err
	}
	b, err := json.MarshalIndent(x, "", "  ")
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(writer, string(b))
	return err
}

func exampleRequest(name string) (any, error) {
	c := map[string]any{"kind": "service_call", "service": "settings-center", "action": "ping", "input": map[string]any{}}
	switch name {
	case "ping":
	case "remember":
		c["service"] = "memory"
		c["action"] = "remember"
		c["input"] = map[string]any{"kind": "测试", "content": "这是一条核验示例，不会实际写入记忆"}
	case "unknown":
		c["service"] = "unknown"
		c["action"] = "execute"
	case "shell":
		c = map[string]any{"kind": "shell", "dialect": "powershell", "command_text": "Get-Content ./notes.txt", "working_dir": "C:/sump/workspace", "platform": "windows"}
	default:
		return nil, errors.New("未知示例，可选 ping / remember / unknown / shell")
	}
	return map[string]any{"command": c}, nil
}

func submit(addr string, request any, writer io.Writer) error {
	raw, err := protocol.EncodePayload(request)
	if err != nil {
		return errors.New("请求不能编码")
	}
	if len(raw) > command.MaxBytes {
		return errors.New("请求超过 32 KiB")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	client, err := protocol.DialContext(ctx, addr, nil)
	if err != nil {
		return errors.New("无法连接安全服务，请先启动测试体验程序")
	}
	defer client.Close()
	env, err := protocol.NewEnvelope(protocol.TypeJump, "security-check", "security", "", protocol.JumpPayload{Action: "check", Input: raw})
	if err != nil {
		return errors.New("请求封装失败")
	}
	response, err := client.Call(ctx, env)
	if err != nil {
		return errors.New("请求超时或连接中断；不能视为允许")
	}
	var payload protocol.ResponsePayload
	if err := response.DecodePayload(&payload); err != nil {
		return errors.New("响应无效")
	}
	if !payload.OK {
		return fmt.Errorf("服务返回错误：%s", payload.Error)
	}
	var result policy.Result
	if err := protocol.DecodeRaw(payload.Data, &result); err != nil {
		return errors.New("核验结果无效")
	}
	if result.Decision != policy.Allow && result.Decision != policy.Review && result.Decision != policy.Deny {
		return errors.New("未知核验结论")
	}
	data, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return errors.New("结果展示失败")
	}
	fmt.Fprintln(writer, string(data))
	return nil
}

// JSON 输入拒绝重复键，并在编码成 MessagePack 前保留整数精度。
func parseJSON(data []byte) (any, error) {
	if len(data) == 0 || len(data) > command.MaxBytes {
		return nil, errors.New("JSON 为空或超过 32 KiB")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	d.UseNumber()
	nodes := 0
	var read func(int) (any, error)
	read = func(depth int) (any, error) {
		nodes++
		if depth > command.MaxDepth || nodes > command.MaxNodes {
			return nil, errors.New("JSON 结构超过上限")
		}
		token, err := d.Token()
		if err != nil {
			return nil, errors.New("JSON 格式错误")
		}
		if delim, ok := token.(json.Delim); ok {
			switch delim {
			case '{':
				m := map[string]any{}
				for d.More() {
					key, err := d.Token()
					if err != nil {
						return nil, err
					}
					k, ok := key.(string)
					if !ok {
						return nil, errors.New("JSON 键必须为文本")
					}
					if _, exists := m[k]; exists {
						return nil, errors.New("JSON 包含重复键")
					}
					if len(m) >= command.MaxItems {
						return nil, errors.New("对象过大")
					}
					v, err := read(depth + 1)
					if err != nil {
						return nil, err
					}
					m[k] = v
				}
				_, err = d.Token()
				return m, err
			case '[':
				a := []any{}
				for d.More() {
					if len(a) >= command.MaxItems {
						return nil, errors.New("数组过大")
					}
					v, err := read(depth + 1)
					if err != nil {
						return nil, err
					}
					a = append(a, v)
				}
				_, err = d.Token()
				return a, err
			default:
				return nil, errors.New("JSON 结构错误")
			}
		}
		if n, ok := token.(json.Number); ok {
			if i, err := strconv.ParseInt(string(n), 10, 64); err == nil {
				return i, nil
			}
			if u, err := strconv.ParseUint(string(n), 10, 64); err == nil {
				return u, nil
			}
			if !strings.ContainsAny(string(n), ".eE") {
				return nil, errors.New("整数超出支持范围")
			}
			f, err := strconv.ParseFloat(string(n), 64)
			if err != nil {
				return nil, errors.New("数值无效")
			}
			return f, nil
		}
		return token, nil
	}
	v, err := read(0)
	if err != nil {
		return nil, err
	}
	if _, err = d.Token(); err != io.EOF {
		return nil, errors.New("JSON 包含多余内容")
	}
	return command.Clone(v)
}
