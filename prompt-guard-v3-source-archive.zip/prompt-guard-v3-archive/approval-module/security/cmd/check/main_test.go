package main

import (
	"testing"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/command"
)

func TestClientJSONIsUnambiguous(t *testing.T) {
	for _, raw := range []string{`{"x":1,"x":2}`, `{"x":18446744073709551616}`, `{} {}`} {
		if _, err := parseJSON([]byte(raw)); err == nil {
			t.Fatal("歧义输入应拒绝")
		}
	}
	v, err := parseJSON([]byte(`{"command":{"kind":"service_call","service":"memory","action":"forget","input":{"id":9007199254740993}}}`))
	if err != nil {
		t.Fatal(err)
	}
	raw, err := protocol.EncodePayload(v)
	if err != nil {
		t.Fatal(err)
	}
	r, err := command.Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	switch n := r.Input["id"].(type) {
	case int64:
		if n != 9007199254740993 {
			t.Fatal("整数精度丢失")
		}
	case uint64:
		if n != 9007199254740993 {
			t.Fatal("整数精度丢失")
		}
	default:
		t.Fatal("整数被改成浮点")
	}
}
