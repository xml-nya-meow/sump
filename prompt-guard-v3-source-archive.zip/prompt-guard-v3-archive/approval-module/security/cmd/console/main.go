// console is a loopback operator UI. It owns the operator identity; models never do.
package main

import (
	"context"
	"crypto/rand"
	"crypto/subtle"
	_ "embed"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/protocol/safevalue"
	"github.com/QAQ-awa-QAQ/sump/service"
)

//go:embed index.html
var page []byte

type event struct {
	At   string `json:"at"`
	Kind string `json:"kind"`
	Text string `json:"text"`
}
type app struct {
	service                     *service.Service
	operator                    *guard.Identity
	identity                    *guard.Identity
	security, token, host, mode string
	mu                          sync.Mutex
	events                      []event
	session, run                string
	delivered                   string
	sending                     bool
}

func (a *app) add(kind, text string) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.events = append(a.events, event{time.Now().Format("15:04:05"), kind, text})
	if len(a.events) > 100 {
		a.events = append([]event(nil), a.events[len(a.events)-100:]...)
	}
}
func (a *app) deliver(_ context.Context, env protocol.Envelope, in protocol.JumpPayload) (any, error) {
	if env.From != "reasoner" {
		return nil, errors.New("DELIVERY_FORBIDDEN")
	}
	var p protocol.DeliverPayload
	if protocol.DecodeRaw(in.Input, &p) != nil || len(p.Text) > 8192 || p.DeliveryID == "" {
		return nil, errors.New("INVALID_DELIVERY")
	}
	a.mu.Lock()
	if p.ConversationID != a.session || (a.run == "" || p.DeliveryID != a.run) {
		a.mu.Unlock()
		return nil, errors.New("STALE_DELIVERY")
	}
	if a.delivered == p.DeliveryID {
		a.mu.Unlock()
		return map[string]bool{"duplicate": true}, nil
	}
	a.delivered = p.DeliveryID
	a.mu.Unlock()
	a.add("assistant", p.Text)
	return map[string]bool{"delivered": true}, nil
}
func (a *app) progress(_ context.Context, env protocol.Envelope, in protocol.JumpPayload) (any, error) {
	if env.From != "reasoner" {
		return nil, errors.New("PROGRESS_FORBIDDEN")
	}
	var p guard.Progress
	if protocol.DecodeRaw(in.Input, &p) != nil {
		return nil, errors.New("INVALID_PROGRESS")
	}
	a.mu.Lock()
	current := p.ConversationID == a.session
	a.mu.Unlock()
	if !current {
		return nil, errors.New("STALE_PROGRESS")
	}
	texts := map[string]string{"waiting_approval": "等待人工审批：请在待审批列表查看操作。", "executing": "已批准，正在执行。", "reviewing": "正在核验候选回复。", "held": "正文未放行：内容不符合策略、上下文超限或语义模型不可用。请查看配置及核验结果。", "delivery_unknown": "交付结果未确认，不会自动重发。", "model_unavailable": "主推理模型未配置或请求失败；请检查主模型配置，当前任务已结束。"}
	text := texts[p.State]
	if text == "" {
		return nil, errors.New("INVALID_PROGRESS_STATE")
	}
	a.add("status", text)
	return map[string]bool{"accepted": true}, nil
}
func reply(w http.ResponseWriter, value any, err error) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	if err != nil {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}
	json.NewEncoder(w).Encode(value)
}
func (a *app) api(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	if r.Host != a.host {
		http.Error(w, "Host rejected", 403)
		return
	}
	if origin := r.Header.Get("Origin"); origin != "" && origin != "http://"+a.host {
		http.Error(w, "Origin rejected", 403)
		return
	}
	if subtle.ConstantTimeCompare([]byte(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")), []byte(a.token)) != 1 {
		http.Error(w, "Session token required", 401)
		return
	}
	if r.Method != http.MethodGet && r.Method != http.MethodPost {
		http.Error(w, "Method rejected", 405)
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 12*time.Second)
	defer cancel()
	if r.Method == http.MethodGet {
		switch r.URL.Path {
		case "/api/events":
			a.mu.Lock()
			out := append([]event(nil), a.events...)
			a.mu.Unlock()
			reply(w, map[string]any{"mode": a.mode, "events": out}, nil)
			return
		case "/api/approvals":
			raw, err := a.operator.Call(ctx, a.security, "security", "approval_list", map[string]any{})
			var out []guard.Status
			if err == nil {
				err = protocol.DecodeRaw(raw, &out)
			}
			reply(w, out, err)
			return
		case "/api/approval":
			raw, err := a.operator.Call(ctx, a.security, "security", "approval_status", guard.Ref{ID: r.URL.Query().Get("id")})
			var out guard.Status
			if err == nil {
				err = protocol.DecodeRaw(raw, &out)
			}
			reply(w, out, err)
			return
		default:
			http.NotFound(w, r)
			return
		}
	}
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, 32<<10))
	if err != nil {
		reply(w, nil, errors.New("输入超过 32 KiB"))
		return
	}
	switch r.URL.Path {
	case "/api/propose":
		value, e := safevalue.ParseJSON(body)
		if e != nil {
			reply(w, nil, e)
			return
		}
		root, ok := value.(map[string]any)
		if !ok {
			reply(w, nil, errors.New("命令必须为对象"))
			return
		}
		c, ok := root["command"].(map[string]any)
		if !ok || c["kind"] != "service_call" || c["service"] != "memory" || c["action"] != "remember" {
			reply(w, nil, errors.New("本版审批闭环仅支持 memory.remember"))
			return
		}
		input, ok := c["input"].(map[string]any)
		if !ok {
			reply(w, nil, errors.New("input 必须为对象"))
			return
		}
		session, ok := input["conversation_id"].(string)
		if !ok || !guard.Identifier(session) {
			reply(w, nil, errors.New("请明确填写 conversation_id"))
			return
		}
		raw, e := protocol.EncodePayload(input)
		if e != nil {
			reply(w, nil, e)
			return
		}
		p := guard.Propose{Operation: guard.Operation{Service: "memory", Action: "remember", Input: raw}, Task: guard.Task{Goal: "评估操作者主动提交的记忆写入操作", Session: session, Revision: protocol.NewID()}, JobID: protocol.NewID(), RoleID: "general", ContextComplete: true, Segments: []guard.Segment{{ID: "request", Source: "user", Text: "用户在本地界面主动提交此具体操作，批准决定另行进行。", Sensitivity: "private"}}}
		data, e := a.service.Call(ctx, "security", "approval_request", p, "", "")
		var out guard.Status
		if e == nil {
			e = protocol.DecodeRaw(data, &out)
		}
		reply(w, out, e)
	case "/api/decision":
		var ref guard.Ref
		if err = safevalue.DecodeStrictObject(body, &ref); err == nil {
			var raw []byte
			raw, err = a.operator.Call(ctx, a.security, "security", "approval_result", ref)
			var out guard.Status
			if err == nil {
				err = protocol.DecodeRaw(raw, &out)
			}
			reply(w, out, err)
		} else {
			reply(w, nil, err)
		}
	case "/api/check", "/api/content":
		var value any
		value, err = safevalue.ParseJSON(body)
		if err != nil {
			reply(w, nil, err)
			return
		}
		raw, err := protocol.EncodePayload(value)
		if err != nil {
			reply(w, nil, err)
			return
		}
		action := "check"
		if r.URL.Path == "/api/content" {
			action = "review_content"
		}
		response, err := a.service.Call(ctx, "security", action, raw, "", "")
		var result map[string]any
		if err == nil {
			err = protocol.DecodeRaw(response, &result)
		}
		reply(w, result, err)
	case "/api/message":
		if a.mode != "project" {
			reply(w, nil, errors.New("独立模块未启动核心推理服务"))
			return
		}
		var p struct {
			Text string `json:"text"`
		}
		if safevalue.DecodeStrictObject(body, &p) != nil || strings.TrimSpace(p.Text) == "" {
			reply(w, nil, errors.New("消息为空或过长"))
			return
		}
		a.mu.Lock()
		if a.sending {
			a.mu.Unlock()
			reply(w, nil, errors.New("上一条请求尚未受理"))
			return
		}
		a.sending = true
		session := a.session
		run := protocol.NewID()
		a.run = run
		a.mu.Unlock()
		defer func() { a.mu.Lock(); a.sending = false; a.mu.Unlock() }()
		a.add("user", p.Text)
		_, addr, err := a.service.Resolve("reasoner")
		var data []byte
		if err == nil {
			data, err = a.identity.CallAs(ctx, addr, "reasoner", "user_message", protocol.UserMessagePayload{Text: p.Text, ConversationID: session}, run, "console")
		}
		var accepted struct {
			RunID string `msgpack:"run_id"`
		}
		if err == nil {
			err = protocol.DecodeRaw(data, &accepted)
			if err == nil && accepted.RunID != run {
				err = errors.New("TASK_ID_MISMATCH")
			}
		}
		if err != nil {
			a.add("status", "请求未确认，请查看核心服务配置和日志。")
		}
		reply(w, map[string]string{"status": "accepted"}, err)
	default:
		http.NotFound(w, r)
	}
}

func main() {
	identityDir := flag.String("identities", "config/identities", "身份目录")
	center := flag.String("center", "ws://127.0.0.1:19000/ws", "设置中心")
	security := flag.String("security", "ws://127.0.0.1:19501/ws", "审批控制端点")
	wsAddr := flag.String("addr", "127.0.0.1:19601", "console 服务地址")
	uiAddr := flag.String("ui", "127.0.0.1:19600", "本地网页地址")
	mode := flag.String("mode", "project", "project 或 module")
	sessionFile := flag.String("session-file", "", "供启动器打开浏览器的临时地址文件")
	flag.Parse()
	host, _, err := net.SplitHostPort(*uiAddr)
	if err != nil || net.ParseIP(host) == nil || !net.ParseIP(host).IsLoopback() {
		log.Fatal("网页界面只允许监听回环 IP")
	}
	id, err := guard.Load(filepath.Join(*identityDir, "console.json"), "console")
	if err != nil {
		log.Fatal(err)
	}
	operator, err := guard.Load(filepath.Join(*identityDir, "operator.json"), "operator")
	if err != nil {
		log.Fatal(err)
	}
	key := make([]byte, 32)
	if _, err = rand.Read(key); err != nil {
		log.Fatal(err)
	}
	a := &app{operator: operator, identity: id, security: *security, token: base64.RawURLEncoding.EncodeToString(key), host: *uiAddr, mode: *mode, session: "console:" + protocol.NewID()}
	a.service = service.New(service.Config{Name: "console", Listen: *wsAddr, Center: *center, Guard: id, MaxMessageBytes: 64 << 10, MaxConcurrentActions: 16, Provides: []protocol.Provide{{Action: "deliver"}, {Action: "progress"}}})
	a.service.Handle("deliver", a.deliver)
	a.service.Handle("progress", a.progress)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if err = a.service.Start(ctx); err != nil {
		log.Fatal(err)
	}
	defer a.service.Shutdown()
	mux := http.NewServeMux()
	mux.HandleFunc("/api/", a.api)
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Host != a.host || r.URL.Path != "/" || r.Method != http.MethodGet {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
		w.Write(page)
	})
	srv := &http.Server{Addr: *uiAddr, Handler: mux, ReadHeaderTimeout: 3 * time.Second, ReadTimeout: 15 * time.Second, WriteTimeout: 20 * time.Second, IdleTimeout: 30 * time.Second}
	listener, err := net.Listen("tcp", *uiAddr)
	if err != nil {
		log.Fatal(err)
	}
	go func() {
		if err := srv.Serve(listener); err != nil && err != http.ErrServerClosed {
			log.Print("网页服务退出")
			stop()
		}
	}()
	url := "http://" + *uiAddr + "/#" + a.token
	if *sessionFile != "" {
		if err := os.WriteFile(*sessionFile, []byte(url), 0600); err != nil {
			log.Fatal("无法保存本地界面入口")
		}
	}
	fmt.Println("本地审批界面：", url)
	<-ctx.Done()
	shutdown, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	_ = srv.Shutdown(shutdown)
}
