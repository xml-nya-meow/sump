// demo 启动两个本地测试服务与交互客户端，退出后关闭自己创建的进程。
package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "体验程序启动失败：", err)
		os.Exit(1)
	}
}

func run() error {
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	binDir := filepath.Dir(exe)
	root := filepath.Dir(binDir)
	for _, name := range []string{"sump-center.exe", "sump-security.exe", "sump-check.exe"} {
		if _, err := os.Stat(filepath.Join(binDir, name)); err != nil {
			return errors.New("缺少程序文件，请先运行 构建程序.cmd")
		}
	}
	centerPort, err := port()
	if err != nil {
		return err
	}
	securityPort, err := port()
	if err != nil {
		return err
	}
	centerAddr := "127.0.0.1:" + strconv.Itoa(centerPort)
	securityAddr := "127.0.0.1:" + strconv.Itoa(securityPort)
	centerURL := "ws://" + centerAddr + "/ws"
	securityURL := "ws://" + securityAddr + "/ws"
	dataDir := filepath.Join(root, "data", fmt.Sprintf("demo-%d-%d", time.Now().Unix(), os.Getpid()))
	if err := os.MkdirAll(dataDir, 0700); err != nil {
		return err
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt)
	defer cancel()
	type child struct {
		cmd *exec.Cmd
		log *os.File
	}
	children := []child{}
	defer func() {
		for i := len(children) - 1; i >= 0; i-- {
			_ = children[i].cmd.Process.Kill()
			_ = children[i].cmd.Wait()
			_ = children[i].log.Close()
		}
	}()
	start := func(name string, args ...string) error {
		f, err := os.OpenFile(filepath.Join(dataDir, name+".log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
		if err != nil {
			return err
		}
		cmd := exec.CommandContext(ctx, filepath.Join(binDir, name+".exe"), args...)
		cmd.Dir = root
		cmd.Stdout = f
		cmd.Stderr = f
		hideChild(cmd)
		if err := cmd.Start(); err != nil {
			_ = f.Close()
			return err
		}
		children = append(children, child{cmd, f})
		return nil
	}
	if err := start("sump-center", "-addr", centerAddr); err != nil {
		return err
	}
	if err := ready(ctx, centerURL); err != nil {
		return fmt.Errorf("设置中心未就绪，日志在 %s", dataDir)
	}
	securityArgs := []string{"-addr", securityAddr, "-center", centerURL, "-audit", filepath.Join(dataDir, "audit.jsonl")}
	contentConfig := filepath.Join(root, "security", "content.local.json")
	if _, err := os.Stat(contentConfig); err == nil {
		securityArgs = append(securityArgs, "-content-config", contentConfig)
	}
	if err := start("sump-security", securityArgs...); err != nil {
		return err
	}
	if err := registered(ctx, centerURL); err != nil {
		return fmt.Errorf("安全服务未完成注册，日志在 %s", dataDir)
	}
	fmt.Printf("已启动本机测试服务：\n设置中心 %s\n安全核验 %s\n日志与审计 %s\n菜单 6 可提交内容请求；语义模型需自行配置。\n退出菜单或按 Ctrl+C 会关闭这次启动的服务。\n", centerURL, securityURL, dataDir)
	client := exec.CommandContext(ctx, filepath.Join(binDir, "sump-check.exe"), "-addr", securityURL)
	client.Dir = root
	client.Stdin = os.Stdin
	client.Stdout = os.Stdout
	client.Stderr = os.Stderr
	err = client.Run()
	if ctx.Err() != nil {
		return nil
	}
	return err
}

func port() (int, error) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return 0, err
	}
	defer ln.Close()
	return ln.Addr().(*net.TCPAddr).Port, nil
}

func ready(ctx context.Context, url string) error {
	deadline := time.NewTimer(15 * time.Second)
	defer deadline.Stop()
	for {
		probe, cancel := context.WithTimeout(ctx, 500*time.Millisecond)
		c, err := protocol.DialContext(probe, url, nil)
		cancel()
		if err == nil {
			_ = c.Close()
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-deadline.C:
			return errors.New("启动超时")
		case <-time.After(100 * time.Millisecond):
		}
	}
}

func registered(ctx context.Context, centerURL string) error {
	deadline := time.NewTimer(15 * time.Second)
	defer deadline.Stop()
	for {
		probe, cancel := context.WithTimeout(ctx, time.Second)
		c, err := protocol.DialContext(probe, centerURL, nil)
		if err == nil {
			env, makeErr := protocol.NewEnvelope(protocol.TypeJump, "demo-client", "settings-center", "", protocol.JumpPayload{Action: "roster"})
			if makeErr == nil {
				response, callErr := c.Call(probe, env)
				if callErr == nil {
					var rp protocol.ResponsePayload
					var roster protocol.RosterPayload
					if response.DecodePayload(&rp) == nil && rp.OK && protocol.DecodeRaw(rp.Data, &roster) == nil {
						for _, card := range roster.Services {
							if card.Name == "security" {
								_ = c.Close()
								cancel()
								return nil
							}
						}
					}
				}
			}
			_ = c.Close()
		}
		cancel()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-deadline.C:
			return errors.New("注册超时")
		case <-time.After(100 * time.Millisecond):
		}
	}
}
