package main

import (
	"bufio"
	"context"
	"errors"
	"flag"
	"fmt"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"net"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strings"
	"time"
)

func main() {
	if err := run(); err != nil {
		fmt.Println("启动未完成：", err)
		fmt.Println("请检查 config、data/logs 和使用说明。按回车关闭。")
		bufio.NewReader(os.Stdin).ReadString('\n')
		os.Exit(1)
	}
}
func run() error {
	mode := flag.String("mode", "project", "project 或 module")
	flag.Parse()
	if *mode != "project" && *mode != "module" {
		return errors.New("invalid mode")
	}
	executable, err := os.Executable()
	if err != nil {
		return err
	}
	bin := filepath.Dir(executable)
	root := filepath.Dir(bin)
	if err = os.Chdir(root); err != nil {
		return err
	}
	for _, p := range []string{"data/logs", "config"} {
		if err = os.MkdirAll(p, 0700); err != nil {
			return err
		}
	}
	identityDir := filepath.Join(root, "config", "identities")
	if _, err = os.Stat(identityDir); os.IsNotExist(err) {
		if err = guard.Init(identityDir, []string{"security", "reasoner", "memory", "console", "operator", "qq", "images", "settings-center"}); err != nil {
			return err
		}
	} else if err != nil {
		return err
	}
	// Separate process environments; no operator private key is passed to other services.
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	commands := []*exec.Cmd{}
	logs := []*os.File{}
	defer func() {
		for i := len(commands) - 1; i >= 0; i-- {
			if commands[i].Process != nil {
				_ = commands[i].Process.Kill()
			}
		}
		for _, f := range logs {
			_ = f.Close()
		}
	}()
	start := func(name, port string, args ...string) error {
		if c, e := net.DialTimeout("tcp", "127.0.0.1:"+port, 200*time.Millisecond); e == nil {
			c.Close()
			return fmt.Errorf("端口 %s 已被占用，未复用未知服务", port)
		}
		logFile, e := os.OpenFile(filepath.Join("data/logs", name+".log"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
		if e != nil {
			return e
		}
		logs = append(logs, logFile)
		cmd := exec.CommandContext(ctx, filepath.Join(bin, name+".exe"), args...)
		cmd.Dir = root
		cmd.Stdout = logFile
		cmd.Stderr = logFile
		hide(cmd)
		if e = cmd.Start(); e != nil {
			return e
		}
		commands = append(commands, cmd)
		done := make(chan error, 1)
		go func() { done <- cmd.Wait() }()
		deadline := time.NewTimer(10 * time.Second)
		defer deadline.Stop()
		tick := time.NewTicker(150 * time.Millisecond)
		defer tick.Stop()
		for {
			select {
			case e := <-done:
				return fmt.Errorf("%s 提前退出，请查看日志：%v", name, e)
			case <-ctx.Done():
				return ctx.Err()
			case <-deadline.C:
				return fmt.Errorf("%s 启动超时", name)
			case <-tick.C:
				c, e := net.DialTimeout("tcp", "127.0.0.1:"+port, 150*time.Millisecond)
				if e == nil {
					c.Close()
					return nil
				}
			}
		}
	}
	center := "ws://127.0.0.1:19000/ws"
	if err = start("sump-center", "19000", "-addr", "127.0.0.1:19000", "-settings", "data/settings.json", "-guard-config", filepath.Join(identityDir, "settings-center.json")); err != nil {
		return err
	}
	securityArgs := []string{"-addr", "127.0.0.1:19501", "-center", center, "-guard-config", filepath.Join(identityDir, "security.json"), "-audit", "data/security-audit.jsonl"}
	if _, err = os.Stat("security/content.local.json"); err == nil {
		securityArgs = append(securityArgs, "-content-config", "security/content.local.json")
	}
	if err = start("sump-security", "19501", securityArgs...); err != nil {
		return err
	}
	if *mode == "project" {
		if err = start("sump-memory", "19201", "-addr", "127.0.0.1:19201", "-center", center, "-guard-config", filepath.Join(identityDir, "memory.json"), "-db", "data/memory.db"); err != nil {
			return err
		}
		args := []string{"-addr", "127.0.0.1:19101", "-center", center, "-guard-config", filepath.Join(identityDir, "reasoner.json")}
		if v := os.Getenv("SUMP_LLM_BASE"); v != "" {
			args = append(args, "-llm-base", v)
		}
		if v := os.Getenv("SUMP_LLM_MODEL"); v != "" {
			args = append(args, "-llm-model", v)
		}
		if err = start("sump-reasoner", "19101", args...); err != nil {
			return err
		}
	}
	sessionPath := filepath.Join(root, "data", "console-session-"+fmt.Sprint(time.Now().UnixNano())+".txt")
	defer os.Remove(sessionPath)
	if err = start("sump-console", "19600", "-identities", identityDir, "-center", center, "-security", "ws://127.0.0.1:19501/ws", "-mode", *mode, "-session-file", sessionPath); err != nil {
		return err
	}
	var url string
	for i := 0; i < 20; i++ {
		b, e := os.ReadFile(sessionPath)
		if e == nil {
			url = strings.TrimSpace(string(b))
			break
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(100 * time.Millisecond):
		}
	}
	if !strings.HasPrefix(url, "http://127.0.0.1:19600/#") {
		return errors.New("本地网页入口未生成")
	}
	fmt.Println("SUMP 已启动。网页入口：", url)
	fmt.Println("此窗口保持打开；按 Ctrl+C 关闭本次启动的服务。首次使用请配置语义模型。")
	openBrowser(url)
	<-ctx.Done()
	return nil
}
