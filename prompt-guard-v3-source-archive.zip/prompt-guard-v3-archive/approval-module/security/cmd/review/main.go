// review 只在用户主动调用时核验指定文件；可展示输出缓冲的放行行为。
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/buffer"
	"github.com/QAQ-awa-QAQ/sump/security/client"
	"github.com/QAQ-awa-QAQ/sump/security/command"
	"github.com/QAQ-awa-QAQ/sump/security/review"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "内容核验未完成：", err)
		os.Exit(1)
	}
}
func readFile(path string, max int64) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("无法打开指定文件")
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, max+1))
	if err != nil || int64(len(b)) > max {
		return nil, fmt.Errorf("文件无法读取或超过大小上限")
	}
	return b, nil
}
func run() error {
	addr := flag.String("addr", "ws://127.0.0.1:9501/ws", "安全服务地址")
	file := flag.String("request", "", "UTF-8 内容请求 JSON 文件")
	candidateFile := flag.String("candidate", "", "输出缓冲候选文本文件，最多 8192 字节")
	release := flag.Bool("release", false, "仅在完整通过后把候选文本打印到终端")
	flag.Parse()
	if *file == "" || (*release && *candidateFile == "") {
		return fmt.Errorf("需要 -request；-release 还需要 -candidate")
	}
	b, err := readFile(*file, command.MaxBytes)
	if err != nil {
		return err
	}
	v, err := command.ParseJSON(b)
	if err != nil {
		return err
	}
	m, ok := v.(map[string]any)
	if !ok {
		return fmt.Errorf("请求必须是 JSON 对象")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if *candidateFile != "" {
		if m["stage"] != "output" {
			return fmt.Errorf("终端输出缓冲示例只支持 output")
		}
		text, err := readFile(*candidateFile, command.MaxString)
		if err != nil {
			return err
		}
		if _, exists := m["candidate"]; exists {
			return fmt.Errorf("使用 -candidate 时请求不能再含 candidate 字段")
		}
		if *release {
			raw, err := protocol.EncodePayload(m)
			if err != nil {
				return err
			}
			pending, err := buffer.New(raw)
			if err != nil {
				return err
			}
			defer pending.Discard()
			if _, err := pending.Write(text); err != nil {
				return err
			}
			x, err := pending.Release(ctx, func(c context.Context, data []byte) (review.Result, error) { return client.Review(c, *addr, data) }, func(c context.Context, output string) error {
				if err := c.Err(); err != nil {
					return err
				}
				_, err := fmt.Fprintln(os.Stdout, output)
				return err
			})
			if x.ContentDigest != "" {
				data, _ := json.MarshalIndent(x, "", "  ")
				fmt.Fprintln(os.Stderr, string(data))
			}
			return err
		}
		m["candidate"] = string(text)
	}
	raw, err := protocol.EncodePayload(m)
	if err != nil {
		return err
	}
	x, err := client.Review(ctx, *addr, raw)
	if err != nil {
		return err
	}
	data, err := json.MarshalIndent(x, "", "  ")
	if err != nil {
		return err
	}
	_, err = fmt.Fprintln(os.Stdout, string(data))
	return err
}
