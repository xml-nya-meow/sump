package command

import "github.com/QAQ-awa-QAQ/sump/protocol/safevalue"

const (
	MaxBytes  = safevalue.MaxBytes
	MaxDepth  = safevalue.MaxDepth
	MaxString = safevalue.MaxString
	MaxItems  = safevalue.MaxItems
	MaxNodes  = safevalue.MaxNodes
)

type Request = safevalue.Request

var (
	Parse       = safevalue.Parse
	ParseObject = safevalue.ParseObject
	Clone       = safevalue.Clone
	Canonical   = safevalue.Canonical
	Digest      = safevalue.Digest
	ValidName   = safevalue.ValidName
)
