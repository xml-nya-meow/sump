package command

import "github.com/QAQ-awa-QAQ/sump/protocol/safevalue"

var (
	ParseJSON          = safevalue.ParseJSON
	DecodeStrictObject = safevalue.DecodeStrictObject
)
