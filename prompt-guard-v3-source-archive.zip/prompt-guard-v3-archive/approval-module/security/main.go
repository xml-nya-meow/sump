// security：命令/内容评估与认证审批服务；业务操作由所属服务执行。
package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/security/audit"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
	"github.com/QAQ-awa-QAQ/sump/security/review"
	"github.com/QAQ-awa-QAQ/sump/security/server"
)

func main() {
	name := flag.String("name", "security", "服务名")
	addr := flag.String("addr", "127.0.0.1:9501", "监听地址")
	center := flag.String("center", "ws://127.0.0.1:9000/ws", "设置中心 WS 地址")
	policyFile := flag.String("policy", "", "可信本地策略 JSON 文件（空 = 保守种子策略）")
	auditPath := flag.String("audit", "data/security-audit.jsonl", "本服务必需的脱敏审计文件")
	timeout := flag.Duration("timeout", 3*time.Second, "单次核验预算（1ms~10s）")
	concurrency := flag.Int("concurrency", 8, "同时受理的核验数（1~128）")
	contentConfig := flag.String("content-config", "", "本地内容策略和可选语义端点配置；空值不请求外部模型")
	contentTimeout := flag.Duration("content-timeout", 8*time.Second, "内容核验总预算（1ms~10s）")
	guardFile := flag.String("guard-config", "", "独立身份文件；审批必须配置")
	approvalTTL := flag.Duration("approval-ttl", 5*time.Minute, "人工审批有效期，最长 10 分钟")
	flag.Parse()
	logger := log.New(os.Stdout, "[security] ", log.LstdFlags|log.Lmicroseconds)
	evaluator := policy.Default()
	if *policyFile != "" {
		loaded, err := policy.LoadFile(*policyFile)
		if err != nil {
			logger.Fatal("策略初始化失败，未启动（未连接中心）")
		}
		evaluator = loaded
	}
	var identity *guard.Identity
	if *guardFile != "" {
		var err error
		identity, err = guard.Load(*guardFile, *name)
		if err != nil {
			logger.Fatal("审批身份配置无效")
		}
	}
	contentPolicy := review.DefaultPolicy()
	contentFault := false
	var analyzer review.Analyzer
	if *contentConfig != "" {
		cfg, loadErr := review.LoadFile(*contentConfig)
		if loadErr != nil {
			contentFault = true
		} else {
			contentPolicy = cfg.Policy
			if cfg.Semantic != nil {
				analyzer, loadErr = review.NewHTTP(*cfg.Semantic)
				if loadErr != nil {
					contentFault = true
					analyzer = nil
				}
			}
		}
	}
	contentEvaluator, err := review.New(contentPolicy, analyzer, evaluator)
	if err != nil {
		contentFault = true
		analyzer = nil
		contentEvaluator, _ = review.New(review.DefaultPolicy(), nil, evaluator)
	}
	if contentFault {
		logger.Println("内容能力配置无效：内容出口暂停，结构化命令核验仍可用")
	}

	sink, err := audit.Open(*auditPath)
	if err != nil {
		logger.Fatal("审计初始化失败，未启动（未连接中心）")
	}
	defer sink.Close()
	s, err := server.New(server.Config{Name: *name, Listen: *addr, Center: *center, Evaluator: evaluator, ContentEvaluator: contentEvaluator, Audit: sink, Timeout: *timeout, ContentTimeout: *contentTimeout, Concurrency: *concurrency, Guard: identity, ApprovalTTL: *approvalTTL}, logger)
	if err != nil {
		logger.Fatal("启动配置无效，未启动（未连接中心）")
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	if err := s.Start(ctx); err != nil {
		logger.Fatal("服务启动失败，请检查本地监听与中心配置")
	}
	defer s.Shutdown()
	logger.Println("check/review_content 为评估接口；认证审批由独立控制入口裁决，执行端领取；审计必需")
	if contentFault {
		s.Report("security_content_config", "内容能力配置异常，受保护内容未放行")
	}
	if analyzer == nil {
		logger.Println("内容语义模型未启用；只按实际请求给出边界/覆盖不足结果")
	}
	<-ctx.Done()
	logger.Println("退出")
}
