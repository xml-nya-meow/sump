// Package policy 提供确定性、失败关闭的有限动作策略。
package policy

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"os"
	"strconv"
	"strings"
	"sync"

	"github.com/QAQ-awa-QAQ/sump/security/command"
)

const (
	Allow  = "allow"
	Review = "require_approval"
	Deny   = "deny"
)

var ErrUnavailable = errors.New("no valid policy")

type Result struct {
	Decision       string   `msgpack:"decision" json:"decision"`
	RiskLevel      string   `msgpack:"risk_level" json:"risk_level"`
	ReasonCodes    []string `msgpack:"reason_codes" json:"reason_codes"`
	Reasons        []string `msgpack:"reasons" json:"reasons"`
	PolicyVersion  string   `msgpack:"policy_version" json:"policy_version"`
	CommandDigest  string   `msgpack:"command_digest" json:"command_digest"`
	AssessmentMode string   `msgpack:"assessment_mode" json:"assessment_mode"`
	Limitations    []string `msgpack:"limitations" json:"limitations"`
}

type Rule struct {
	Service    string         `json:"service"`
	Action     string         `json:"action"`
	Decision   string         `json:"decision"`
	ExactInput map[string]any `json:"exact_input,omitempty"`
}
type Document struct {
	Version string `json:"version"`
	Rules   []Rule `json:"rules"`
}
type Engine struct {
	mu  sync.RWMutex
	doc Document
}

// Default 的放行范围仅限空参数 ping；写记忆要人工批准，配置变更硬拒绝。
func Default() *Engine {
	e, _ := New(Document{Version: "seed-v3", Rules: []Rule{
		{Service: "settings-center", Action: "ping", Decision: Allow, ExactInput: map[string]any{}},
		{Service: "memory", Action: "remember", Decision: Review},
		{Service: "memory", Action: "forget", Decision: Review},
		{Service: "settings-center", Action: "set_setting", Decision: Deny},
		{Service: "settings-center", Action: "reset_setting", Decision: Deny},
	}})
	return e
}

func New(doc Document) (*Engine, error) {
	e := &Engine{}
	if err := e.Replace(doc); err != nil {
		return nil, err
	}
	return e, nil
}

// Replace 完整验证与深拷贝后原子替换，外部 map 修改不影响已安装策略。
func (e *Engine) Replace(doc Document) error {
	if !command.ValidName(doc.Version) || len(doc.Rules) == 0 || len(doc.Rules) > 128 {
		return errors.New("策略版本或规则数量无效")
	}
	cloned := Document{Version: doc.Version, Rules: make([]Rule, len(doc.Rules))}
	for i, r := range doc.Rules {
		if !command.ValidName(r.Service) || !command.ValidName(r.Action) {
			return errors.New("策略服务或动作名无效")
		}
		if r.Decision != Allow && r.Decision != Review && r.Decision != Deny {
			return errors.New("策略决定无效")
		}
		if r.Decision == Allow && r.ExactInput == nil {
			return errors.New("放行规则必须声明 exact_input")
		}
		cloned.Rules[i] = r
		if r.ExactInput != nil {
			v, err := command.Clone(r.ExactInput)
			if err != nil {
				return err
			}
			cloned.Rules[i].ExactInput = v.(map[string]any)
		}
	}
	e.mu.Lock()
	e.doc = cloned
	e.mu.Unlock()
	return nil
}

func answer(r command.Request, version, decision, code, reason string) Result {
	risk := "high"
	if decision == Allow {
		risk = "low"
	}
	if decision == Review {
		risk = "medium"
	}
	return Result{Decision: decision, RiskLevel: risk, ReasonCodes: []string{code}, Reasons: []string{reason}, PolicyVersion: version, CommandDigest: r.Digest, AssessmentMode: "advisory", Limitations: []string{"check 结果不是执行授权；受保护动作另走审批协议", "业务许可和执行端资源状态不由 check 证明"}}
}

func (e *Engine) Evaluate(ctx context.Context, r command.Request) (Result, error) {
	if err := ctx.Err(); err != nil {
		return Result{}, err
	}
	e.mu.RLock()
	defer e.mu.RUnlock()
	if e.doc.Version == "" {
		return Result{}, ErrUnavailable
	}
	result := func(decision, code, reason string) Result { return answer(r, e.doc.Version, decision, code, reason) }
	if r.Unsupported {
		return result(Deny, "UNSUPPORTED_FIELDS", "含未支持的上下文或执行字段，不能自动放行"), nil
	}
	if r.Kind == "shell" {
		x := result(Deny, "UNSUPPORTED_SHELL_ANALYSIS", "尚未支持可靠 Shell 语法与执行环境核验")
		x.RiskLevel = "unknown"
		return x, nil
	}
	if r.Kind != "service_call" {
		return result(Deny, "UNKNOWN_COMMAND_KIND", "不支持的命令类型"), nil
	}
	for _, decision := range []string{Deny, Review, Allow} {
		for _, rule := range e.doc.Rules {
			if rule.Service != r.Service || rule.Action != r.Action || rule.Decision != decision {
				continue
			}
			if rule.ExactInput != nil && !bytes.Equal(command.Canonical(rule.ExactInput), command.Canonical(r.Input)) {
				continue
			}
			if decision == Review && !validKnownInput(r) {
				return result(Deny, "INVALID_ACTION_INPUT", "已知动作的参数不完整或不在支持范围内"), nil
			}
			code, reason := "POLICY_DENY", "命中受信策略的硬拒绝规则"
			if decision == Review {
				code, reason = "HUMAN_APPROVAL_REQUIRED", "此操作需要可信人工审批；本次没有签发执行授权"
			}
			if decision == Allow {
				code, reason = "EXACT_INPUT_ALLOWED", "命中受信策略的有限动作及完整参数规则"
			}
			return result(decision, code, reason), nil
		}
	}
	x := result(Deny, "NO_MATCHING_RULE", "未命中明确策略，默认不放行")
	x.RiskLevel = "unknown"
	return x, nil
}

// LoadFile 有界读取可信本地策略；不支持通过模型或网络请求改策略。
func LoadFile(path string) (*Engine, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, 64<<10+1))
	if err != nil {
		return nil, err
	}
	if len(b) > 64<<10 {
		return nil, errors.New("策略文件超过上限")
	}
	v, err := decodeJSON(b)
	if err != nil {
		return nil, err
	}
	m, ok := v.(map[string]any)
	if !ok || len(m) != 2 {
		return nil, errors.New("策略结构无效")
	}
	version, ok := m["version"].(string)
	if !ok {
		return nil, errors.New("策略版本无效")
	}
	rules, ok := m["rules"].([]any)
	if !ok {
		return nil, errors.New("策略规则无效")
	}
	doc := Document{Version: version}
	for _, value := range rules {
		rm, ok := value.(map[string]any)
		if !ok {
			return nil, errors.New("策略规则必须为对象")
		}
		for key := range rm {
			if key != "service" && key != "action" && key != "decision" && key != "exact_input" {
				return nil, errors.New("策略包含未知规则字段")
			}
		}
		svc, sok := rm["service"].(string)
		act, aok := rm["action"].(string)
		decision, dok := rm["decision"].(string)
		if !sok || !aok || !dok {
			return nil, errors.New("策略规则字段无效")
		}
		rule := Rule{Service: svc, Action: act, Decision: decision}
		if input, present := rm["exact_input"]; present {
			parsed, ok := input.(map[string]any)
			if !ok {
				return nil, errors.New("exact_input 必须为对象")
			}
			rule.ExactInput = parsed
		}
		doc.Rules = append(doc.Rules, rule)
	}
	return New(doc)
}

func decodeJSON(b []byte) (any, error) {
	if len(b) > 64<<10 {
		return nil, errors.New("策略参数超过上限")
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.UseNumber()
	nodes := 0
	var read func(int) (any, error)
	read = func(depth int) (any, error) {
		nodes++
		if depth > command.MaxDepth || nodes > command.MaxNodes {
			return nil, errors.New("策略结构超过上限")
		}
		t, err := d.Token()
		if err != nil {
			return nil, errors.New("策略 JSON 无效")
		}
		if delim, ok := t.(json.Delim); ok {
			if delim == '{' {
				m := map[string]any{}
				for d.More() {
					key, err := d.Token()
					if err != nil {
						return nil, err
					}
					k, ok := key.(string)
					if !ok {
						return nil, errors.New("策略键无效")
					}
					if _, exists := m[k]; exists {
						return nil, errors.New("策略重复键")
					}
					v, err := read(depth + 1)
					if err != nil {
						return nil, err
					}
					m[k] = v
				}
				_, err = d.Token()
				return m, err
			}
			if delim == '[' {
				a := []any{}
				for d.More() {
					v, err := read(depth + 1)
					if err != nil {
						return nil, err
					}
					a = append(a, v)
				}
				_, err = d.Token()
				return a, err
			}
			return nil, errors.New("策略结构无效")
		}
		return t, nil
	}
	v, err := read(0)
	if err != nil {
		return nil, err
	}
	if _, err = d.Token(); err != io.EOF {
		return nil, errors.New("策略包含多余数据")
	}
	return numbers(v)
}

func numbers(v any) (any, error) {
	switch x := v.(type) {
	case json.Number:
		if n, err := strconv.ParseInt(string(x), 10, 64); err == nil {
			return n, nil
		}
		if n, err := strconv.ParseUint(string(x), 10, 64); err == nil {
			return n, nil
		}
		if !strings.ContainsAny(string(x), ".eE") {
			return nil, errors.New("策略整数超出支持范围")
		}
		f, err := strconv.ParseFloat(string(x), 64)
		if err != nil {
			return nil, errors.New("策略数值无效")
		}
		return f, nil
	case map[string]any:
		for k, val := range x {
			n, err := numbers(val)
			if err != nil {
				return nil, err
			}
			x[k] = n
		}
		return x, nil
	case []any:
		for i, val := range x {
			n, err := numbers(val)
			if err != nil {
				return nil, err
			}
			x[i] = n
		}
		return x, nil
	case nil, bool, string, int64, uint64, float64:
		return x, nil
	default:
		return nil, errors.New("策略值类型无效")
	}
}

func validKnownInput(r command.Request) bool {
	if r.Service != "memory" {
		return true
	}
	if r.Action == "forget" {
		if len(r.Input) != 1 {
			return false
		}
		switch id := r.Input["id"].(type) {
		case uint64:
			return id > 0 && id <= 1<<63-1
		case int64:
			return id > 0
		}
		return false
	}
	if r.Action != "remember" {
		return true
	}
	for key := range r.Input {
		if key != "kind" && key != "content" && key != "priority" && key != "conversation_id" {
			return false
		}
	}
	kind, kok := r.Input["kind"].(string)
	content, cok := r.Input["content"].(string)
	if !kok || !cok || strings.TrimSpace(kind) == "" || strings.TrimSpace(content) == "" || len(kind) > 128 || len(content) > 8192 {
		return false
	}
	if val, present := r.Input["priority"]; present {
		switch p := val.(type) {
		case int64:
			if p < -1000000 || p > 1000000 {
				return false
			}
		case uint64:
			if p > 1000000 {
				return false
			}
		default:
			return false
		}
	}
	if val, present := r.Input["conversation_id"]; present {
		cid, ok := val.(string)
		if !ok || len(cid) > 256 {
			return false
		}
	}
	return true
}
