package policy

import (
 "context"
 "testing"
 "github.com/QAQ-awa-QAQ/sump/protocol"
 "github.com/QAQ-awa-QAQ/sump/security/command"
)

func TestPriorityFollowsOriginalIntegerMemoryContract(t *testing.T){
 for _,tc:=range []struct{value any;decision string}{{int64(20),Review},{int64(-20),Review},{int64(0),Review},{0.5,Deny},{int64(1000001),Deny}}{
  raw,e:=protocol.EncodePayload(map[string]any{"command":map[string]any{"kind":"service_call","service":"memory","action":"remember","input":map[string]any{"kind":"test","content":"bounded priority","priority":tc.value,"conversation_id":"qq:private:123"}}});if e!=nil{t.Fatal(e)}
  req,e:=command.Parse(raw);if e!=nil{t.Fatal(e)}
  out,e:=Default().Evaluate(context.Background(),req);if e!=nil||out.Decision!=tc.decision{t.Fatalf("priority=%v got %v err=%v",tc.value,out.Decision,e)}
 }
}
