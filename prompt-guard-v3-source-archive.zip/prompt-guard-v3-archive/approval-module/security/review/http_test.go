package review

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestHTTPKeepsTemplateInDataMessage(t *testing.T) {
	calls := 0
	s := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		calls++
		var body struct {
			Messages []struct {
				Role    string `json:"role"`
				Content string `json:"content"`
			} `json:"messages"`
		}
		if json.NewDecoder(req.Body).Decode(&body) != nil || len(body.Messages) != 2 {
			t.Error("bad request")
		}
		if body.Messages[0].Role != "system" || strings.Contains(body.Messages[0].Content, "UNTRUSTED_TEMPLATE_MARKER") {
			t.Error("untrusted text entered policy message")
		}
		if body.Messages[1].Role != "user" || !strings.Contains(body.Messages[1].Content, "UNTRUSTED_TEMPLATE_MARKER") {
			t.Error("data boundary missing")
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"choices": []any{map[string]any{"finish_reason": "stop", "message": map[string]any{"role": "assistant", "content": `{"coverage":"complete","risk":"low","findings":[]}`}}}})
	}))
	defer s.Close()
	a, err := NewHTTP(HTTPConfig{Endpoint: s.URL + "/v1/chat/completions", Model: "fixture", ResponseFormat: "json_object", TimeoutMS: 1000, AllowedSources: []string{"file"}})
	if err != nil {
		t.Fatal(err)
	}
	r := fixture(t, "context")
	r.Segments[0].Text = "UNTRUSTED_TEMPLATE_MARKER"
	d, err := a.Analyze(context.Background(), Packet{Request: r, Role: DefaultPolicy().Roles[0], SourceTrust: "unverified"})
	if err != nil || d.Risk != "low" || calls != 1 {
		t.Fatalf("unexpected result: %#v, %v", d, err)
	}
	r.Segments[0].Sensitivity = "secret"
	_, err = a.Analyze(context.Background(), Packet{Request: r})
	var unavailable *Unavailable
	if !errors.As(err, &unavailable) || unavailable.Code != "SENSITIVE_CONTEXT_NOT_SENT" || calls != 1 {
		t.Fatal("secret segment submitted")
	}
}

func TestHTTPDoesNotFollowRedirect(t *testing.T) {
	targetCalls := 0
	target := httptest.NewServer(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { targetCalls++ }))
	defer target.Close()
	source := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, target.URL, http.StatusTemporaryRedirect)
	}))
	defer source.Close()
	a, err := NewHTTP(HTTPConfig{Endpoint: source.URL + "/chat/completions", Model: "fixture", ResponseFormat: "json_object", TimeoutMS: 1000, AllowedSources: []string{"file"}})
	if err != nil {
		t.Fatal(err)
	}
	_, err = a.Analyze(context.Background(), Packet{Request: fixture(t, "context")})
	if err == nil || targetCalls != 0 {
		t.Fatal("redirect followed")
	}
}

func TestSuspiciousFastDraftEscalates(t *testing.T) {
	fast := &fixedAnalyzer{draft: Draft{Coverage: "complete", Risk: "medium", Findings: []Finding{}}}
	deep := &fixedAnalyzer{draft: Draft{Coverage: "complete", Risk: "low", Findings: []Finding{}}}
	c := &Cascade{Fast: fast, Deep: deep}
	d, err := c.Analyze(context.Background(), Packet{Request: fixture(t, "context")})
	if err != nil || d.Risk != "low" || fast.calls != 1 || deep.calls != 1 {
		t.Fatal("suspicious result did not escalate")
	}
}
