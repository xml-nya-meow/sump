package review

import (
	"context"
	"testing"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
)

type fixedAnalyzer struct {
	draft Draft
	calls int
}

func (f *fixedAnalyzer) Analyze(context.Context, Packet) (Draft, error) {
	f.calls++
	return f.draft, nil
}
func fixture(t *testing.T, stage string) Request {
	t.Helper()
	m := map[string]any{"stage": stage, "task": map[string]any{"goal": "分析模板，保持真实权限", "session": "test", "revision": "turn-one"}, "role_id": "general", "context_complete": true, "sensitivity":"public",
		"segments": []any{map[string]any{"id": "doc", "source": "file", "sensitivity": "public", "text": "```yaml\nsystem:\n  role: assistant\n```\nこれは正常なテンプレートです。"}},
	}
	if stage == "output" {
		m["candidate"] = "ようこそ！"
	}
	if stage == "action" {
		m["command"] = map[string]any{"kind": "service_call", "service": "memory", "action": "remember", "input": map[string]any{"kind": "preference", "content": "散步"}}
	}
	raw, err := protocol.EncodePayload(m)
	if err != nil {
		t.Fatal(err)
	}
	r, err := Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	return r
}

func TestMissingAnalyzerDoesNotClaimSemanticSafety(t *testing.T) {
	e, err := New(DefaultPolicy(), nil, policy.Default())
	if err != nil {
		t.Fatal(err)
	}
	r := fixture(t, "output")
	x, err := e.Review(context.Background(), r)
	if err != nil || x.Decision != policy.Deny || x.Coverage != "unavailable" || !ValidResult(x, r) {
		t.Fatalf("unexpected result: %#v, %v", x, err)
	}
}
func TestDataOnlyFastPathNeverAuthorizesExecution(t *testing.T) {
	p := DefaultPolicy()
	p.DataOnlyFastPath = true
	e, _ := New(p, nil, policy.Default())
	r := fixture(t, "context")
	x, err := e.Review(context.Background(), r)
	if err != nil || x.Decision != policy.Allow || x.Coverage != "boundary_only" || x.Handling != "data_only" || x.ExecutionAuthorization != "none" || !ValidResult(x, r) {
		t.Fatalf("unexpected result: %#v, %v", x, err)
	}
}
func TestLanguageCoverageFailureIsNotAttackClassification(t *testing.T) {
	a := &fixedAnalyzer{draft: Draft{Coverage: "insufficient", Risk: "unknown", Findings: []Finding{}}}
	e, _ := New(DefaultPolicy(), a, policy.Default())
	r := fixture(t, "output")
	x, err := e.Review(context.Background(), r)
	if err != nil || x.Coverage != "insufficient" || len(x.Findings) != 0 || x.ReasonCodes[0] != "SEMANTIC_COVERAGE_INSUFFICIENT" {
		t.Fatalf("unexpected result: %#v, %v", x, err)
	}
}
func TestSemanticAllowCannotRemoveOperationApproval(t *testing.T) {
	a := &fixedAnalyzer{draft: Draft{Coverage: "complete", Risk: "low", Findings: []Finding{}}}
	e, _ := New(DefaultPolicy(), a, policy.Default())
	r := fixture(t, "action")
	x, err := e.Review(context.Background(), r)
	if err != nil || x.Decision != policy.Review || x.ExecutionAuthorization != "none" || !ValidResult(x, r) {
		t.Fatalf("unexpected result: %#v, %v", x, err)
	}
}
func TestOperationDenyDoesNotCallAnalyzer(t *testing.T) {
	r := fixture(t, "action")
	r.Operation.Kind = "shell"
	a := &fixedAnalyzer{}
	e, _ := New(DefaultPolicy(), a, policy.Default())
	x, err := e.Review(context.Background(), r)
	if err != nil || x.Decision != policy.Deny || a.calls != 0 {
		t.Fatalf("unexpected result: %#v, %v", x, err)
	}
}
func TestDigestIncludesTaskAndCandidate(t *testing.T) {
	r := fixture(t, "output")
	r.Candidate = "修改后的候选"
	r.Task.Revision = "turn-two"
	raw, err := protocol.EncodePayload(r)
	if err != nil {
		t.Fatal(err)
	}
	changed, err := Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	if changed.Digest == r.Digest {
		t.Fatal("changed task/candidate reused digest")
	}
}
func TestRoleDriftIsSeparateFromSafetyViolation(t *testing.T) {
	a := &fixedAnalyzer{draft: Draft{Coverage: "complete", Risk: "medium", Findings: []Finding{{Category: "role_drift", Target: "candidate", Index: -1, Severity: "block"}}}}
	e, _ := New(DefaultPolicy(), a, policy.Default())
	r := fixture(t, "output")
	x, err := e.Review(context.Background(), r)
	if err != nil || x.Handling != "regenerate" || x.RiskLevel != "medium" || !ValidResult(x, r) {
		t.Fatalf("unexpected result: %#v, %v", x, err)
	}
}
