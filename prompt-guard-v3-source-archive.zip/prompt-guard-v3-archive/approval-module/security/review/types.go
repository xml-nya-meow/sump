// Package review 提供按请求触发的内容评估，不把正文中的指令升级为权限。
package review

import (
	"encoding/json"
	"errors"
	"strings"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/security/command"
)

const MaxSegments = 16

type Task struct {
	Goal     string `json:"goal" msgpack:"goal"`
	Session  string `json:"session" msgpack:"session"`
	Revision string `json:"revision" msgpack:"revision"`
}
type Segment struct {
	ID           string `json:"id" msgpack:"id"`
	Source       string `json:"source" msgpack:"source"`
	Text         string `json:"text" msgpack:"text"`
	LanguageHint string `json:"language_hint,omitempty" msgpack:"language_hint,omitempty"`
	Sensitivity  string `json:"sensitivity" msgpack:"sensitivity"`
}
type Request struct {
	Sensitivity     string           `json:"sensitivity,omitempty" msgpack:"sensitivity,omitempty"` // whole-packet disclosure classification
	Stage           string           `json:"stage" msgpack:"stage"`
	Task            Task             `json:"task" msgpack:"task"`
	RoleID          string           `json:"role_id" msgpack:"role_id"`
	Segments        []Segment        `json:"segments" msgpack:"segments"`
	Candidate       string           `json:"candidate,omitempty" msgpack:"candidate,omitempty"`
	Command         map[string]any   `json:"command,omitempty" msgpack:"command,omitempty"`
	ContextComplete bool             `json:"context_complete" msgpack:"context_complete"`
	Digest          string           `json:"-" msgpack:"-"`
	Operation       *command.Request `json:"-" msgpack:"-"`
}

type Finding struct {
	Category string `json:"category" msgpack:"category"`
	Target   string `json:"target" msgpack:"target"`
	Index    int    `json:"index" msgpack:"index"`
	Severity string `json:"severity" msgpack:"severity"`
}

// Draft 没有自由文本、工具请求或授权字段；所有解释使用程序固定短语。
type Draft struct {
	Coverage string    `json:"coverage"`
	Risk     string    `json:"risk"`
	Findings []Finding `json:"findings"`
}
type Result struct {
	Decision               string    `json:"decision" msgpack:"decision"`
	RiskLevel              string    `json:"risk_level" msgpack:"risk_level"`
	ReasonCodes            []string  `json:"reason_codes" msgpack:"reason_codes"`
	Reasons                []string  `json:"reasons" msgpack:"reasons"`
	PolicyVersion          string    `json:"policy_version" msgpack:"policy_version"`
	ContentDigest          string    `json:"content_digest" msgpack:"content_digest"`
	AssessmentMode         string    `json:"assessment_mode" msgpack:"assessment_mode"`
	Coverage               string    `json:"coverage" msgpack:"coverage"`
	Handling               string    `json:"handling" msgpack:"handling"`
	AnalyzerStatus         string    `json:"analyzer_status" msgpack:"analyzer_status"`
	Findings               []Finding `json:"findings" msgpack:"findings"`
	SourceTrust            string    `json:"source_trust" msgpack:"source_trust"`
	ExecutionAuthorization string    `json:"execution_authorization" msgpack:"execution_authorization"`
	Limitations            []string  `json:"limitations" msgpack:"limitations"`
}

func member(value string, options ...string) bool {
	for _, s := range options {
		if value == s {
			return true
		}
	}
	return false
}

func Parse(raw []byte) (Request, error) {
	root, err := command.ParseObject(raw)
	if err != nil {
		return Request{}, err
	}
	b, err := json.Marshal(root)
	if err != nil {
		return Request{}, err
	}
	var r Request
	if err := command.DecodeStrictObject(b, &r); err != nil {
		return r, errors.New("内容请求存在未知字段或无效类型")
	}
	// 避免通用 JSON 转换影响命令内整数/浮点类别及完整参数摘要。
	if c, ok := root["command"].(map[string]any); ok {
		r.Command = c
	}
	if !member(r.Stage, "input", "context", "action", "output", "memory") {
		return r, errors.New("stage 无效")
	}
	if strings.TrimSpace(r.Task.Goal) == "" || !guard.Identifier(r.Task.Session) || !guard.Identifier(r.Task.Revision) {
		return r, errors.New("task.goal、session、revision 必填；标识需为短名")
	}
	if r.Sensitivity != "" && !member(r.Sensitivity, "public", "private", "secret", "unknown") {
		return r, errors.New("sensitivity 无效")
	}
	if !command.ValidName(r.RoleID) {
		return r, errors.New("role_id 必须为有效短名")
	}
	if len(r.Segments) > MaxSegments {
		return r, errors.New("最多 16 段相关上下文")
	}
	seen := map[string]bool{}
	for _, s := range r.Segments {
		if !command.ValidName(s.ID) || seen[s.ID] {
			return r, errors.New("段落 ID 无效或重复")
		}
		seen[s.ID] = true
		if !member(s.Source, "user", "file", "web", "tool", "memory", "assistant", "unknown") {
			return r, errors.New("来源类型无效")
		}
		if !member(s.Sensitivity, "public", "private", "secret", "unknown") {
			return r, errors.New("敏感度标签无效")
		}
		if len(s.LanguageHint) > 64 || strings.TrimSpace(s.Text) == "" {
			return r, errors.New("段落为空或语言提示过长")
		}
	}
	if member(r.Stage, "output", "memory") && strings.TrimSpace(r.Candidate) == "" {
		return r, errors.New("该位置必须提供候选内容")
	}
	if member(r.Stage, "input", "context") && len(r.Segments) == 0 {
		return r, errors.New("该位置必须提供段落")
	}
	if !member(r.Stage, "output", "memory") && r.Candidate != "" {
		return r, errors.New("候选内容只能用于输出/记忆位置")
	}
	if r.Stage == "action" {
		if r.Command == nil {
			return r, errors.New("action 必须提供 command")
		}
		packed, err := protocol.EncodePayload(map[string]any{"command": r.Command})
		if err != nil {
			return r, errors.New("命令不能编码")
		}
		op, err := command.Parse(packed)
		if err != nil {
			return r, err
		}
		r.Operation = &op
	} else if r.Command != nil {
		return r, errors.New("command 只能用于 action")
	}
	// 摘要绑定原文、完整上下文、角色引用及任务代次，不绑定归一化文本。
	r.Digest = command.Digest(root)
	return r, nil
}

func validDraft(d Draft, r Request) bool {
	if !member(d.Coverage, "complete", "insufficient") || !member(d.Risk, "low", "medium", "high", "unknown") || d.Findings == nil || len(d.Findings) > 16 {
		return false
	}
	for _, f := range d.Findings {
		if !member(f.Category, "authority_override", "fabricated_authorization", "task_hijack", "unauthorized_disclosure", "unauthorized_action", "memory_poisoning", "role_drift") || !member(f.Severity, "info", "warning", "block") {
			return false
		}
		switch f.Target {
		case "segment":
			if f.Index < 0 || f.Index >= len(r.Segments) {
				return false
			}
		case "task":
			if f.Index != -1 {
				return false
			}
		case "candidate":
			if f.Index != -1 || r.Candidate == "" {
				return false
			}
		case "command":
			if f.Index != -1 || r.Operation == nil {
				return false
			}
		default:
			return false
		}
	}
	return true
}
