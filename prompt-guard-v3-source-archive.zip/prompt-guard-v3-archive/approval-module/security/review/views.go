package review

import (
	"encoding/base64"
	"net/url"
	"strings"
	"unicode"
	"unicode/utf8"
)

type View struct {
	Target string `json:"target"`
	Index  int    `json:"index"`
	Kind   string `json:"kind"`
	Text   string `json:"text"`
}

// AnalysisViews 只生成辅助视图：每段最多两个、合计 16 KiB、解码一层。
// 不改变原文、命令参数或摘要，不将解码后的内容作为指令。
func AnalysisViews(r Request) []View {
	views := []View{}
	budget := 16 << 10
	add := func(target string, index int, kind, text, original string) {
		if text == original || len(text) == 0 || len(text) > budget || !utf8.ValidString(text) || len(views) >= 32 {
			return
		}
		views = append(views, View{target, index, kind, text})
		budget -= len(text)
	}
	scan := func(target string, index int, text string) {
		// 空白/不可见格式字符的分析视图；不声称实现完整 NFKC 或所有混淆处理。
		normal := strings.Join(strings.FieldsFunc(text, func(r rune) bool { return unicode.IsSpace(r) || unicode.Is(unicode.Cf, r) }), " ")
		add(target, index, "whitespace_format_view", normal, text)
		if decoded, err := url.PathUnescape(text); err == nil {
			add(target, index, "percent_decoded", decoded, text)
		}
		compact := strings.TrimSpace(text)
		if len(compact) >= 16 && len(compact) <= 8192 && len(views) < 32 {
			for _, enc := range []*base64.Encoding{base64.StdEncoding, base64.RawStdEncoding, base64.URLEncoding, base64.RawURLEncoding} {
				b, err := enc.DecodeString(compact)
				if err == nil && utf8.Valid(b) {
					add(target, index, "base64_decoded", string(b), text)
					break
				}
			}
		}
	}
	for i, s := range r.Segments {
		scan("segment", i, s.Text)
	}
	if r.Candidate != "" {
		scan("candidate", -1, r.Candidate)
	}
	return views
}
