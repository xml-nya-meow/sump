package server

import (
	"context"
	"errors"
	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/security/approval"
	"github.com/QAQ-awa-QAQ/sump/security/command"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
	"github.com/QAQ-awa-QAQ/sump/security/review"
	"strings"
)

func (s *Server) installApprovals() {
	s.approvals = approval.New(s.cfg.Audit, s.cfg.ApprovalTTL)
	for _, action := range []string{"approval_request", "approval_status", "approval_result", "approval_list", "approval_cancel", "approval_consume"} {
		a := action
		s.Handle(a, func(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload) (any, error) {
			return s.approvalAction(ctx, env, in, a)
		})
	}
}
func (s *Server) approvalAction(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload, action string) (out any, err error) {
	defer func() {
		if recover() != nil {
			out = nil
			err = s.fault("security_panic")
		} else if errors.Is(err, approval.ErrStore) {
			err = s.fault("security_store")
		}
	}()
	if s.cfg.Guard == nil {
		return nil, errors.New("APPROVAL_AUTH_NOT_CONFIGURED")
	}
	operator := env.From == "operator"
	if action == "approval_request" {
		if env.From != "reasoner" && env.From != "console" {
			return nil, errors.New("APPROVAL_FORBIDDEN")
		}
		var p guard.Propose
		if guard.Decode(in.Input, &p) != nil {
			return nil, errors.New("INVALID_REQUEST")
		}
		// This release only grants one known action, regardless of a custom advisory policy.
		if p.Operation.Service != "memory" || p.Operation.Action != "remember" {
			return guard.Status{State: "denied", Code: "UNSUPPORTED_EXECUTION_ACTION"}, nil
		}
		if _, err := guard.Digest(env.From, p); err != nil {
			return nil, errors.New("INVALID_TASK_OR_OPERATION")
		}
		cmd, err := guard.Command(p.Operation)
		if err != nil {
			return nil, errors.New("INVALID_OPERATION")
		}
		input := cmd["input"].(map[string]any)
		for key := range input {
			if key != "kind" && key != "content" && key != "priority" && key != "conversation_id" {
				return guard.Status{State: "denied", Code: "UNKNOWN_MEMORY_PARAMETER"}, nil
			}
		}
		var mem protocol.RememberPayload
		if protocol.DecodeRaw(p.Operation.Input, &mem) != nil || mem.Priority < -1000000 || mem.Priority > 1000000 || strings.TrimSpace(mem.Kind) == "" || len(mem.Kind) > 128 || strings.TrimSpace(mem.Content) == "" || len(mem.Content) > 8192 {
			return guard.Status{State: "denied", Code: "INVALID_MEMORY_PARAMETERS"}, nil
		}
		// Explicit session scope; never silently turn a session operation into global memory.
		if input["conversation_id"] != p.Task.Session {
			return guard.Status{State: "denied", Code: "MEMORY_SCOPE_REQUIRED"}, nil
		}
		raw, _ := protocol.EncodePayload(map[string]any{"command": cmd})
		req, err := command.Parse(raw)
		if err != nil {
			return nil, errors.New("INVALID_OPERATION")
		}
		op, err := s.cfg.Evaluator.Evaluate(ctx, req)
		if err != nil {
			return nil, s.fault("security_policy")
		}
		if !validResult(op, req) {
			return nil, s.fault("security_internal")
		}
		if op.Decision == policy.Deny {
			return guard.Status{State: "denied", Code: "OPERATION_POLICY_DENY"}, nil
		}
		cr := guard.ContentRequest{Stage: "action", Task: p.Task, RoleID: p.RoleID, Segments: p.Segments, Command: cmd, ContextComplete: p.ContextComplete, Sensitivity: "private"}
		contentRaw, _ := protocol.EncodePayload(cr)
		result, err := s.reviewContent(ctx, env, protocol.JumpPayload{Action: "review_content", Input: contentRaw})
		if err != nil {
			return nil, err
		}
		rr := result.(review.Result)
		if rr.Coverage != "complete" || (rr.Decision != policy.Allow && rr.Decision != policy.Review) {
			code := "CONTENT_HELD"
			if len(rr.ReasonCodes) > 0 {
				code = rr.ReasonCodes[0]
			}
			return guard.Status{State: "denied", Code: code}, nil
		}
		// Human confirmation remains mandatory for memory writes, even with an advisory allow rule.
		return s.approvals.Create(ctx, env.From, p, op.PolicyVersion+"/"+rr.PolicyVersion)
	}
	if action == "approval_list" {
		if !operator {
			return nil, errors.New("APPROVAL_FORBIDDEN")
		}
		return s.approvals.List(), nil
	}
	var ref guard.Ref
	if guard.Decode(in.Input, &ref) != nil {
		return nil, errors.New("INVALID_REFERENCE")
	}
	switch action {
	case "approval_result":
		if !operator {
			return nil, errors.New("APPROVAL_FORBIDDEN")
		}
		return s.approvals.Decide(ctx, ref)
	case "approval_status":
		return s.approvals.Status(ctx, ref, env.From, operator)
	case "approval_cancel":
		if !guard.Identifier(ref.RunID) {
			return nil, errors.New("INVALID_RUN")
		}
		return map[string]bool{"cancelled": true}, s.approvals.Cancel(ctx, env.From, ref.RunID)
	case "approval_consume":
		if env.From != "memory" {
			return nil, errors.New("APPROVAL_FORBIDDEN")
		}
		return s.approvals.Consume(ctx, ref, env.From)
	}
	return nil, errors.New("UNKNOWN_ACTION")
}
