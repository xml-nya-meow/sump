// Package server 将纯核验与自身故障反馈接入服务骨架。
package server

import (
	"context"
	"errors"
	"log"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/security/approval"
	"github.com/QAQ-awa-QAQ/sump/security/audit"
	"github.com/QAQ-awa-QAQ/sump/security/command"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
	"github.com/QAQ-awa-QAQ/sump/security/review"
	"github.com/QAQ-awa-QAQ/sump/service"
)

type Evaluator interface {
	Evaluate(context.Context, command.Request) (policy.Result, error)
}
type Config struct {
	Guard                *guard.Identity
	ApprovalTTL          time.Duration
	Name, Listen, Center string
	Evaluator            Evaluator
	ContentEvaluator     review.Evaluator
	Audit                audit.Sink
	Timeout              time.Duration
	ContentTimeout       time.Duration
	Concurrency          int
	HeartbeatInterval    time.Duration
}
type Server struct {
	approvals *approval.Store
	*service.Service
	cfg    Config
	logger *log.Logger
}

// RequestError 是请求或正常取消错误，不进入中心的自身故障通道。
type RequestError struct{ Code, Message string }

func (e *RequestError) Error() string { return e.Code + ": " + e.Message }

// ServiceFault 可由内部核验依赖明确标记故障类别；不携带敏感异常原文。
type ServiceFault struct{ Kind string }

func (e *ServiceFault) Error() string         { return "INTERNAL_ERROR: 安全核验暂不可用" }
func requestError(code, message string) error { return &RequestError{Code: code, Message: message} }

func New(cfg Config, logger *log.Logger) (*Server, error) {
	if cfg.Name == "" {
		cfg.Name = "security"
	}
	if cfg.Listen == "" {
		cfg.Listen = "127.0.0.1:9501"
	}
	if cfg.Center == "" {
		cfg.Center = "ws://127.0.0.1:9000/ws"
	}
	if !command.ValidName(cfg.Name) {
		return nil, errors.New("服务名无效")
	}
	if cfg.Evaluator == nil || cfg.Audit == nil {
		return nil, errors.New("核验器和必需审计不可缺失")
	}
	if cfg.Timeout == 0 {
		cfg.Timeout = 3 * time.Second
	}
	if cfg.Timeout < time.Millisecond || cfg.Timeout > 10*time.Second {
		return nil, errors.New("核验预算应为 1ms 至 10s")
	}
	if cfg.ContentTimeout == 0 {
		cfg.ContentTimeout = 8 * time.Second
	}
	if cfg.ContentTimeout < time.Millisecond || cfg.ContentTimeout > 10*time.Second {
		return nil, errors.New("内容核验预算应为 1ms 至 10s")
	}
	if cfg.ContentEvaluator == nil {
		engine, err := review.New(review.DefaultPolicy(), nil, cfg.Evaluator)
		if err != nil {
			return nil, err
		}
		cfg.ContentEvaluator = engine
	}
	if cfg.Concurrency == 0 {
		cfg.Concurrency = 8
	}
	if cfg.Concurrency < 1 || cfg.Concurrency > 128 {
		return nil, errors.New("并发上限应为 1 至 128")
	}
	if logger == nil {
		logger = log.Default()
	}
	s := &Server{cfg: cfg, logger: logger}
	actionTimeout := cfg.Timeout
	if cfg.ContentTimeout > actionTimeout {
		actionTimeout = cfg.ContentTimeout
	}
	s.Service = service.New(service.Config{
		Name: cfg.Name, Listen: cfg.Listen, Center: cfg.Center, HeartbeatInterval: cfg.HeartbeatInterval,
		ActionTimeout: actionTimeout, MaxMessageBytes: 64 << 10, MaxConcurrentActions: cfg.Concurrency,
		Guard: cfg.Guard, ActionConcurrency: map[string]int{"review_content": 4, "approval_request": 4},
		Description: "命令与内容评估、独立人工审批；本版绑定 memory.remember，服务自身不执行业务动作",
		Provides: []protocol.Provide{
			{Action: "approval_request", Tool: false}, {Action: "approval_status", Tool: false}, {Action: "approval_list", Tool: false}, {Action: "approval_result", Tool: false}, {Action: "approval_cancel", Tool: false}, {Action: "approval_consume", Tool: false},
			{Action: "check", Tool: false, Input: "{command:{kind:service_call,service,action,input},context?:{purpose}}；Shell 保守拒绝", Output: "{decision:allow|require_approval|deny, risk_level,reason_codes,reasons,policy_version,command_digest,assessment_mode:advisory,limitations}"},
			{Action: "review_content", Tool: false, Input: "{stage:input|context|action|output|memory,task:{goal,session,revision},role_id,segments:[{id,source,text,sensitivity,language_hint?}],context_complete,candidate?,command?}", Output: "{decision,risk_level,reason_codes,policy_version,content_digest,coverage,handling,analyzer_status,findings,assessment_mode:advisory,execution_authorization:none}"},
		},
		Logger: logger,
	})
	s.Handle("check", s.check)
	s.Handle("review_content", s.reviewContent)
	s.installApprovals()
	return s, nil
}

func (s *Server) fault(kind string) error {
	// 只使用固定摘要，绝不直接输出异常文本或待核验数据。
	message := "安全核验服务自身异常，本次未放行"
	s.logger.Printf("[%s] %s", kind, message)
	s.Report(kind, message)
	return &ServiceFault{Kind: kind}
}
func cancelled(err error) bool {
	return errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded)
}

func (s *Server) check(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload) (out any, err error) {
	ctx, cancel := context.WithTimeout(ctx, s.cfg.Timeout)
	defer cancel()
	defer func() {
		if recover() != nil {
			out = nil
			err = s.fault("security_panic")
		}
	}()
	if env.V != protocol.ProtocolVersion || env.To != s.cfg.Name {
		return nil, requestError("INVALID_REQUEST", "协议版本或目标无效")
	}
	if ctx.Err() != nil {
		return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
	}
	req, parseErr := command.Parse(in.Input)
	if parseErr != nil {
		return nil, requestError("INVALID_REQUEST", parseErr.Error())
	}
	result, evalErr := s.cfg.Evaluator.Evaluate(ctx, req)
	if evalErr != nil {
		if cancelled(evalErr) {
			return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
		}
		var badRequest *RequestError
		if errors.As(evalErr, &badRequest) {
			return nil, badRequest
		}
		kind := "security_internal"
		if errors.Is(evalErr, policy.ErrUnavailable) {
			kind = "security_policy"
		}
		var fault *ServiceFault
		if errors.As(evalErr, &fault) {
			switch fault.Kind {
			case "security_policy", "security_store", "security_analyzer", "security_internal":
				kind = fault.Kind
			}
		}
		return nil, s.fault(kind)
	}
	// 分析器是内部接口，但仍验证结果，拒绝遗漏或伪造允许结论。
	if !validResult(result, req) {
		return nil, s.fault("security_internal")
	}
	if ctx.Err() != nil {
		return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
	}
	if auditErr := s.cfg.Audit.Record(ctx, audit.Record{At: time.Now().UTC(), Decision: result.Decision, PolicyVersion: result.PolicyVersion, CommandDigest: result.CommandDigest, ReasonCodes: result.ReasonCodes}); auditErr != nil {
		if errors.Is(auditErr, audit.ErrBusy) {
			return nil, requestError("BUSY", "审计队列繁忙，本次未放行")
		}
		if cancelled(auditErr) {
			return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
		}
		return nil, s.fault("security_store")
	}
	if ctx.Err() != nil {
		return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
	}
	return result, nil
}

func (s *Server) reviewContent(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload) (out any, err error) {
	ctx, cancel := context.WithTimeout(ctx, s.cfg.ContentTimeout)
	defer cancel()
	defer func() {
		if recover() != nil {
			out = nil
			err = s.fault("security_panic")
		}
	}()
	if env.V != protocol.ProtocolVersion || env.To != s.cfg.Name {
		return nil, requestError("INVALID_REQUEST", "协议版本或目标无效")
	}
	if ctx.Err() != nil {
		return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
	}
	req, parseErr := review.Parse(in.Input)
	if parseErr != nil {
		return nil, requestError("INVALID_REQUEST", parseErr.Error())
	}
	result, evalErr := s.cfg.ContentEvaluator.Review(ctx, req)
	if evalErr != nil {
		if cancelled(evalErr) {
			return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
		}
		kind := "security_internal"
		if errors.Is(evalErr, policy.ErrUnavailable) {
			kind = "security_policy"
		}
		return nil, s.fault(kind)
	}
	if !review.ValidResult(result, req) {
		return nil, s.fault("security_internal")
	}
	if ctx.Err() != nil {
		return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
	}
	if auditErr := s.cfg.Audit.Record(ctx, audit.Record{At: time.Now().UTC(), Action: "review_content", Decision: result.Decision, PolicyVersion: result.PolicyVersion, ContentDigest: result.ContentDigest, Coverage: result.Coverage, AnalyzerStatus: result.AnalyzerStatus, ReasonCodes: result.ReasonCodes}); auditErr != nil {
		if errors.Is(auditErr, audit.ErrBusy) {
			return nil, requestError("BUSY", "审计队列繁忙，本次未放行")
		}
		if cancelled(auditErr) {
			return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
		}
		return nil, s.fault("security_store")
	}
	if ctx.Err() != nil {
		return nil, requestError("REQUEST_CANCELLED", "核验已取消或超时")
	}
	return result, nil
}

func validResult(r policy.Result, req command.Request) bool {
	if r.Decision != policy.Allow && r.Decision != policy.Review && r.Decision != policy.Deny {
		return false
	}
	if r.RiskLevel != "low" && r.RiskLevel != "medium" && r.RiskLevel != "high" && r.RiskLevel != "unknown" {
		return false
	}
	if r.Decision == policy.Allow && r.RiskLevel != "low" {
		return false
	}
	if r.CommandDigest != req.Digest || !command.ValidName(r.PolicyVersion) || r.AssessmentMode != "advisory" {
		return false
	}
	if len(r.ReasonCodes) == 0 || len(r.ReasonCodes) > 8 || len(r.Reasons) == 0 || len(r.Reasons) > 8 || len(r.Limitations) == 0 || len(r.Limitations) > 8 {
		return false
	}
	for _, items := range [][]string{r.ReasonCodes, r.Reasons, r.Limitations} {
		for _, s := range items {
			if len(s) == 0 || len(s) > 1024 {
				return false
			}
		}
	}
	return true
}
