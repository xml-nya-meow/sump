package tests

import (
	"context"
	"errors"
	"io"
	"log"
	"strings"
	"testing"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/security/audit"
	"github.com/QAQ-awa-QAQ/sump/security/policy"
	"github.com/QAQ-awa-QAQ/sump/security/review"
	"github.com/QAQ-awa-QAQ/sump/security/server"
)

type reviewFunc func(context.Context, review.Request) (review.Result, error)

func (f reviewFunc) Review(ctx context.Context, r review.Request) (review.Result, error) {
	return f(ctx, r)
}
func contentInput() map[string]any {
	return map[string]any{"stage": "output", "task": map[string]any{"goal": "欢迎用户", "session": "test", "revision": "turn-one"}, "role_id": "general", "segments": []any{}, "candidate": "secret-test-placeholder", "context_complete": true}
}
func TestContentUnavailableIsBusinessResultNotCenterFault(t *testing.T) {
	s, center := newService(t, policy.Default(), nil, 0)
	p := call(t, s, "review_content", contentInput())
	var x review.Result
	if !p.OK || protocol.DecodeRaw(p.Data, &x) != nil || x.Decision != policy.Deny || x.ReasonCodes[0] != "ANALYZER_NOT_CONFIGURED" {
		t.Fatalf("unexpected: %#v %#v", p, x)
	}
	select {
	case got := <-center.reports:
		t.Fatalf("false report: %#v", got)
	case <-time.After(100 * time.Millisecond):
	}
}
func TestContentOwnFaultIsReportedWithoutText(t *testing.T) {
	center := newCenter(t)
	s, err := server.New(server.Config{Listen: "127.0.0.1:0", Center: center.url(), Evaluator: policy.Default(), ContentEvaluator: reviewFunc(func(context.Context, review.Request) (review.Result, error) {
		return review.Result{}, errors.New("secret-test-placeholder")
	}), Audit: auditFunc(func(context.Context, audit.Record) error { return nil })}, log.New(io.Discard, "", 0))
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	if err := s.Start(ctx); err != nil {
		t.Fatal(err)
	}
	defer s.Shutdown()
	p := call(t, s, "review_content", contentInput())
	if p.OK || strings.Contains(p.Error, "secret-test-placeholder") {
		t.Fatal("own fault leaked text or allowed request")
	}
	select {
	case got := <-center.reports:
		if got.payload.Kind != "security_internal" || strings.Contains(got.payload.Message, "secret-test-placeholder") {
			t.Fatalf("bad report: %#v", got)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("missing own-fault report")
	}
}
