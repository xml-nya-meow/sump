@echo off
cd /d "%~dp0"
"%~dp0bin\sump-launcher.exe" -mode module
