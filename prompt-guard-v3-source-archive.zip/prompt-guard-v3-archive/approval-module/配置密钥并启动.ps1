$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
$taskOldLLM=$env:SUMP_LLM_API_KEY
$taskOldSecurity=$env:SUMP_SECURITY_API_KEY
function Read-TaskSecret([string]$Prompt){
 $taskSecure=Read-Host $Prompt -AsSecureString
 $taskPtr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($taskSecure)
 try{return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($taskPtr)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($taskPtr);$taskSecure.Dispose()}
}
try{
 if(Test-Path -LiteralPath './reasoner'){$env:SUMP_LLM_API_KEY=Read-TaskSecret 'Main model API key (hidden, empty keeps existing)';if(-not $env:SUMP_LLM_API_KEY){$env:SUMP_LLM_API_KEY=$taskOldLLM}}
 $env:SUMP_SECURITY_API_KEY=Read-TaskSecret 'Review model API key (hidden, empty keeps existing)'
 if(-not $env:SUMP_SECURITY_API_KEY){$env:SUMP_SECURITY_API_KEY=$taskOldSecurity}
 $taskMode='module';if(Test-Path -LiteralPath './reasoner'){$taskMode='project'}
 & ./bin/sump-launcher.exe -mode $taskMode
}finally{$env:SUMP_LLM_API_KEY=$taskOldLLM;$env:SUMP_SECURITY_API_KEY=$taskOldSecurity}
