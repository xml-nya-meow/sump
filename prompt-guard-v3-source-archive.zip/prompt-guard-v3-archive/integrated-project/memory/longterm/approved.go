package longterm

import (
	"context"
	"database/sql"
	"errors"
	"github.com/QAQ-awa-QAQ/sump/protocol"
	"strings"
	"time"
)

var ErrReceiptMismatch = errors.New("RECEIPT_MISMATCH")

// AddApproved commits the write and its approval receipt in the same owning database.
func (s *Store) AddApproved(ctx context.Context, approvalID, digest, operationDigest string, p protocol.RememberPayload, source string) (protocol.RememberResult, error) {
	if strings.TrimSpace(p.Kind) == "" || strings.TrimSpace(p.Content) == "" || p.Priority < -1000000 || p.Priority > 1000000 || p.ConversationID == "" {
		return protocol.RememberResult{}, errors.New("INVALID_MEMORY")
	}
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return protocol.RememberResult{}, err
	}
	defer tx.Rollback()
	var oldDigest, oldOperation string
	var old protocol.RememberResult
	err = tx.QueryRowContext(ctx, `SELECT digest,operation_digest,memory_id,created FROM approval_receipts WHERE approval_id=?`, approvalID).Scan(&oldDigest, &oldOperation, &old.ID, &old.Created)
	if err == nil {
		if oldDigest != digest || oldOperation != operationDigest {
			return old, ErrReceiptMismatch
		}
		return old, nil
	}
	if !errors.Is(err, sql.ErrNoRows) {
		return old, err
	}
	kind, content := strings.TrimSpace(p.Kind), strings.TrimSpace(p.Content)
	var id int64
	err = tx.QueryRowContext(ctx, `SELECT id FROM memories WHERE status='active' AND kind=? AND content=? AND priority=? AND conversation_id=? LIMIT 1`, kind, content, p.Priority, p.ConversationID).Scan(&id)
	created := false
	if errors.Is(err, sql.ErrNoRows) {
		now := time.Now().UTC().Format(time.RFC3339Nano)
		res, e := tx.ExecContext(ctx, `INSERT INTO memories(kind,content,priority,source,conversation_id,status,created_at,updated_at) VALUES(?,?,?,?,?,'active',?,?)`, kind, content, p.Priority, source, p.ConversationID, now, now)
		if e != nil {
			return old, e
		}
		id, err = res.LastInsertId()
		created = true
	}
	if err != nil && !errors.Is(err, sql.ErrNoRows) {
		return old, err
	}
	if _, err = tx.ExecContext(ctx, `INSERT INTO approval_receipts(approval_id,digest,operation_digest,memory_id,created) VALUES(?,?,?,?,?)`, approvalID, digest, operationDigest, id, created); err != nil {
		return old, err
	}
	if err = tx.Commit(); err != nil {
		return old, err
	}
	return protocol.RememberResult{ID: id, Created: created}, nil
}

func (s *Store) ApprovedReceipt(ctx context.Context, id, digest, operationDigest string) (protocol.RememberResult, bool, error) {
	var out protocol.RememberResult
	var d, op string
	err := s.db.QueryRowContext(ctx, `SELECT digest,operation_digest,memory_id,created FROM approval_receipts WHERE approval_id=?`, id).Scan(&d, &op, &out.ID, &out.Created)
	if errors.Is(err, sql.ErrNoRows) {
		return out, false, nil
	}
	if err != nil {
		return out, false, err
	}
	if d != digest || op != operationDigest {
		return out, false, ErrReceiptMismatch
	}
	return out, true, nil
}
