// memory：SUMP v2 的记忆服务（第一批）。
// 会话历史存储 + 上下文组装：recall 收到调用方托管的任务上下文 →
// 注入记忆后以 resume 发回（触发其“完全启动”）。
package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"

	"github.com/QAQ-awa-QAQ/sump/memory/longterm"
	"github.com/QAQ-awa-QAQ/sump/memory/server"
	"github.com/QAQ-awa-QAQ/sump/memory/store"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
)

func main() {
	name := flag.String("name", "memory", "服务名")
	addr := flag.String("addr", "127.0.0.1:9201", "监听地址（host:port）")
	center := flag.String("center", "ws://127.0.0.1:9000/ws", "设置中心 WS 地址")
	dbPath := flag.String("db", "data/memory.db", "SQLite 数据文件路径")
	history := flag.Int("history", 12, "recall 返回的最近消息条数")
	guardFile := flag.String("guard-config", "", "独立服务身份；集成启动器自动指定")
	flag.Parse()
	var identity *guard.Identity
	if *guardFile != "" {
		var err error
		identity, err = guard.Load(*guardFile, *name)
		if err != nil {
			log.Fatal("服务身份配置无效")
		}
	}

	logger := log.New(os.Stdout, "[memory] ", log.LstdFlags|log.Lmicroseconds)

	st, err := store.Open(*dbPath)
	if err != nil {
		logger.Fatalf("打开数据库失败: %v", err)
	}
	defer st.Close()

	// 长期记忆与会话库共享同一句柄（同进程同库：跨表事务才成立）。
	lt, err := longterm.Open(st.DB())
	if err != nil {
		logger.Fatalf("初始化长期记忆失败: %v", err)
	}

	s := server.New(server.Config{Guard: identity,
		Name:         *name,
		Listen:       *addr,
		Center:       *center,
		Store:        st,
		Longterm:     lt,
		HistoryLimit: *history,
	}, logger)
	if err := s.Start(context.Background()); err != nil {
		logger.Fatalf("启动失败: %v", err)
	}
	defer s.Shutdown()

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	<-sig
	logger.Println("退出")
}
