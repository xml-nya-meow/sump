package server

import (
	"context"
	"errors"
	"github.com/QAQ-awa-QAQ/sump/memory/longterm"
	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
)

func (s *Server) guardedExecute(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload) (any, error) {
	if s.cfg.Guard == nil || env.From != "reasoner" {
		return nil, errors.New("EXECUTION_AUTH_REQUIRED")
	}
	var x guard.Execute
	if guard.Decode(in.Input, &x) != nil {
		return nil, errors.New("INVALID_EXECUTION")
	}
	if x.Operation.Service != s.cfg.Name || x.Operation.Action != "remember" || x.Approval.Actor != env.From {
		return nil, errors.New("EXECUTION_SCOPE")
	}
	digest, err := guard.OperationDigest(x.Operation)
	if err != nil || digest != x.Approval.InputDigest {
		return nil, errors.New("EXECUTION_PARAMETERS_CHANGED")
	}
	var p protocol.RememberPayload
	if guard.Decode(x.Operation.Input, &p) != nil || p.ConversationID != x.Session || p.Priority < -1000000 || p.Priority > 1000000 {
		return nil, errors.New("INVALID_MEMORY_SCOPE")
	}
	if s.cfg.Longterm == nil {
		return nil, errors.New("MEMORY_UNAVAILABLE")
	}
	receipt, found, err := s.cfg.Longterm.ApprovedReceipt(ctx, x.Approval.ID, x.Approval.Digest, digest)
	if err != nil {
		if errors.Is(err, longterm.ErrReceiptMismatch) {
			return nil, errors.New("EXECUTION_PARAMETERS_CHANGED")
		}
		s.Report("memory_store", "审批执行记录读取失败")
		return nil, errors.New("MEMORY_STORE_FAILURE")
	}
	if found {
		return receipt, nil
	}
	// Commit boundary: the owning task atomically marks this exact job as executing.
	// Cancellation after this boundary cannot retract an operation already in flight.
	raw, err := s.Call(ctx, env.From, "guard_commit", x.Approval, env.Trace, "")
	if err != nil {
		return nil, errors.New("TASK_NOT_ACTIVE")
	}
	var active struct {
		Allowed bool `msgpack:"allowed"`
	}
	if protocol.DecodeRaw(raw, &active) != nil || !active.Allowed {
		return nil, errors.New("TASK_NOT_ACTIVE")
	}
	raw, err = s.Call(ctx, "security", "approval_consume", x.Approval, env.Trace, "")
	if err != nil {
		return nil, errors.New("APPROVAL_UNCONFIRMED")
	}
	var status guard.Status
	if protocol.DecodeRaw(raw, &status) != nil || status.ID != x.Approval.ID || status.Digest != x.Approval.Digest || status.Session != x.Session || status.State != "consumed" || status.Code != "EXECUTION_CLAIMED" {
		return nil, errors.New("APPROVAL_NOT_EXECUTABLE")
	}
	result, err := s.cfg.Longterm.AddApproved(ctx, x.Approval.ID, x.Approval.Digest, digest, p, env.From)
	if err != nil {
		if errors.Is(err, longterm.ErrReceiptMismatch) {
			return nil, errors.New("EXECUTION_PARAMETERS_CHANGED")
		}
		s.Report("memory_store", "审批动作存储事务失败；不自动重放")
		return nil, errors.New("EXECUTION_OUTCOME_UNCONFIRMED")
	}
	return result, nil
}
