package server

import (
	"context"
	"errors"
	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"strconv"
)

func (s *Server) actionProgress(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload) (any, error) {
	if s.cfg.Guard == nil || env.From != s.cfg.Reasoner {
		return nil, errors.New("PROGRESS_AUTH_REQUIRED")
	}
	var p guard.Progress
	if protocol.DecodeRaw(in.Input, &p) != nil {
		return nil, errors.New("INVALID_PROGRESS")
	}
	kind, id, ok := parseConversation(p.ConversationID)
	if !ok || kind != "private" || id != s.cfg.Owner {
		return nil, errors.New("PROGRESS_SCOPE")
	}
	texts := map[string]string{"waiting_approval": "操作正在等待批准，请打开本地审批面板。", "executing": "已批准，正在执行。", "reviewing": "正在核验回复。", "held": "本次回复暂未通过核验或核验不可用，正文未发送。", "model_unavailable": "主推理模型不可用，请检查配置。", "delivery_unknown": "交付结果未确认，不会自动重发。"}
	text := texts[p.State]
	if text == "" {
		return nil, errors.New("INVALID_PROGRESS_STATE")
	}
	uid, err := strconv.ParseInt(id, 10, 64)
	if err != nil {
		return nil, err
	}
	err = s.sendPrivate(ctx, uid, text)
	return map[string]bool{"accepted": err == nil}, err
}
