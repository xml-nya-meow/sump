// reasoner：SUMP v2 的单步推理服务。
// 每收到一次输入（任务入口 / 自跳 / 工具结果注入）调用一次 LLM，产出下一步动作
// （工具派发 / 自跳续跑 / 交付）；任务窗口内的上下文由黑板持有，循环不驻留本服务。
package main

import (
	"context"
	"flag"
	"log"
	"os"
	"os/signal"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/reasoner/llm"
	"github.com/QAQ-awa-QAQ/sump/reasoner/server"
)

func main() {
	name := flag.String("name", "reasoner", "服务名")
	addr := flag.String("addr", "127.0.0.1:9101", "监听地址（host:port）")
	center := flag.String("center", "ws://127.0.0.1:9000/ws", "设置中心 WS 地址")
	memorySvc := flag.String("memory", "memory", "记忆服务名（完全启动链的另一半）")
	imagesSvc := flag.String("images", "images", "图片服务名（推理前取图内联）")
	llmBase := flag.String("llm-base", "https://api.deepseek.com", "LLM API 地址（OpenAI 兼容）")
	llmKey := flag.String("llm-key", llmKeyFromEnvironment(), "LLM API Key（优先 SUMP_LLM_API_KEY，其次 DEEPSEEK_API_KEY）")
	llmModel := flag.String("llm-model", "deepseek-chat", "LLM 模型名")
	toolConc := flag.Int("tool-concurrency", 10, "单会话工具并发上限（-1 = 不限制）")
	toolTimeout := flag.Duration("tool-timeout", 60*time.Second, "单个工具调用的执行超时")
	toolNotify := flag.String("tool-notify", "each", "工具结果通知模式：each=逐条唤醒 / batch=攒批唤醒（设置中心 tool.notify_mode 覆盖此项）")
	guardFile := flag.String("guard-config", "", "独立服务身份；集成启动器自动指定")
	flag.Parse()
	var identity *guard.Identity
	if *guardFile != "" {
		var err error
		identity, err = guard.Load(*guardFile, *name)
		if err != nil {
			log.Fatal("服务身份配置无效")
		}
	}

	logger := log.New(os.Stdout, "[reasoner] ", log.LstdFlags|log.Lmicroseconds)
	if *llmKey == "" {
		logger.Printf("警告: 未配置 LLM Key（-llm-key、SUMP_LLM_API_KEY 或 DEEPSEEK_API_KEY），user_message 将无法推理")
	}
	var llmClient llm.Client
	if *llmKey != "" {
		llmClient = llm.NewDeepSeekClient(*llmBase, *llmKey, *llmModel)
	}

	s := server.New(server.Config{Guard: identity, Name: *name, Listen: *addr, Center: *center, Memory: *memorySvc, Images: *imagesSvc, LLM: llmClient, ToolConcurrency: *toolConc, ToolTimeout: *toolTimeout, NotifyMode: *toolNotify}, logger)
	if err := s.Start(context.Background()); err != nil {
		logger.Fatalf("启动失败: %v", err)
	}
	defer s.Shutdown()

	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	<-sig
	logger.Println("退出")
}

func llmKeyFromEnvironment() string {
	if v := os.Getenv("SUMP_LLM_API_KEY"); v != "" {
		return v
	}
	return os.Getenv("DEEPSEEK_API_KEY")
}
