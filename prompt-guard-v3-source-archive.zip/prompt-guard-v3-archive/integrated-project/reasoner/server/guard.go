package server

import (
	"context"
	"encoding/json"
	"errors"
	"strconv"
	"strings"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
	"github.com/QAQ-awa-QAQ/sump/protocol/guard"
	"github.com/QAQ-awa-QAQ/sump/protocol/safevalue"
	"github.com/QAQ-awa-QAQ/sump/reasoner/llm"
)

func allWaiting(jobs map[string]pendingJob) bool {
	if len(jobs) == 0 {
		return false
	}
	for _, j := range jobs {
		if !j.waiting {
			return false
		}
	}
	return true
}
func hasWaiting(jobs map[string]pendingJob) bool {
	for _, j := range jobs {
		if j.waiting {
			return true
		}
	}
	return false
}

// workflowSend classifies remote failures as workflow state, never as this service's fault.
func (s *Server) workflowSend(to, action string, payload any, trace, boss string) {
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
		defer cancel()
		if _, err := s.Call(ctx, to, action, payload, trace, boss); err != nil {
			s.logger.Printf("工作流消息 %s/%s 未确认", to, action)
		}
	}()
}
func (s *Server) progress(st *taskState, state string) {
	if st.boss == "" {
		return
	}
	ctx, cancel := context.WithTimeout(st.ctx, 2*time.Second)
	defer cancel()
	_, _ = s.Call(ctx, st.boss, "progress", guard.Progress{ConversationID: st.cid, State: state}, st.trace, "")
}
func (s *Server) cancelApprovals(st *taskState) {
	if s.cfg.Guard == nil {
		return
	}
	s.workflowSend("security", "approval_cancel", guard.Ref{RunID: st.runID}, st.trace, "")
}

// Keep all relevant bounded text; overflow is explicit rather than silently claiming coverage.
func (s *Server) reviewContext(st *taskState) (guard.Task, []guard.Segment, bool) {
	st.mu.Lock()
	messages := append([]llm.Message(nil), st.messages...)
	st.mu.Unlock()
	task := guard.Task{Goal: "完成当前用户任务", Session: st.cid, Revision: st.runID}
	segments := []guard.Segment{}
	complete := true
	for _, m := range messages {
		if len(m.ImageIDs) > 0 {
			complete = false
		}
		if m.Role == "system" {
			continue
		}
		source := m.Source
		if source == "" {
			source = m.Role
		}
		if source != "user" && source != "assistant" && source != "tool" && source != "memory" {
			source = "unknown"
		}
		text := m.Content
		if len(m.ToolCalls) > 0 {
			b, err := json.Marshal(m.ToolCalls)
			if err != nil {
				complete = false
			} else {
				text += "\nProposed tool calls (data):\n" + string(b)
			}
		}
		if source == "user" && strings.TrimSpace(m.Content) != "" {
			task.Goal = m.Content
		}
		if strings.TrimSpace(text) == "" {
			continue
		}
		if len(text) > safevalue.MaxString || len(segments) >= 16 {
			complete = false
			continue
		}
		segments = append(segments, guard.Segment{ID: "s" + strconv.Itoa(len(segments)), Source: source, Text: text, Sensitivity: "private"})
	}
	if len(task.Goal) > safevalue.MaxString {
		complete = false
		task.Goal = "原始任务超过核验输入范围"
	}
	return task, segments, complete
}

func (s *Server) runGuardedJob(st *taskState, call llm.ToolCall) {
	content, err := s.approveAndRun(st, call)
	if err != nil {
		content = "操作未完成：" + err.Error()
	}
	s.boardResult(st, call, content)
}
func (s *Server) approveAndRun(st *taskState, call llm.ToolCall) (string, error) {
	svc, action, ok := parseToolName(call.Function.Name)
	if !ok || !s.toolAdvertised(svc, action) {
		return "", errors.New("TOOL_UNAVAILABLE")
	}
	if svc != s.cfg.Memory || svc != "memory" || action != "remember" {
		return "", errors.New("ACTION_NOT_IN_CURRENT_GUARDED_SCOPE")
	}
	raw, err := argsToRaw(call.Function.Arguments)
	if err != nil {
		return "", errors.New("INVALID_TOOL_PARAMETERS")
	}
	values, err := safevalue.ParseObject(raw)
	if err != nil {
		return "", errors.New("INVALID_TOOL_PARAMETERS")
	}
	// Bind the service's actual session before showing the approval; do not trust model routing.
	if value, present := values["conversation_id"]; present && value != st.cid {
		return "", errors.New("CROSS_SESSION_MEMORY_DENIED")
	}
	values["conversation_id"] = st.cid
	if _, present := values["priority"]; !present {
		values["priority"] = int64(0)
	}
	raw, err = protocol.EncodePayload(values)
	if err != nil {
		return "", errors.New("INVALID_TOOL_PARAMETERS")
	}
	task, segments, complete := s.reviewContext(st)
	proposal := guard.Propose{Operation: guard.Operation{Service: svc, Action: action, Input: raw}, Task: task, JobID: call.ID, Segments: segments, ContextComplete: complete, RoleID: "general"}
	digest, err := guard.Digest(s.cfg.Name, proposal)
	if err != nil {
		return "", errors.New("REVIEW_INPUT_LIMIT")
	}
	inputDigest, _ := guard.OperationDigest(proposal.Operation)
	ctx, cancel := context.WithTimeout(st.ctx, 10*time.Second)
	data, err := s.Call(ctx, "security", "approval_request", proposal, st.trace, "")
	cancel()
	if err != nil {
		return "", errors.New("REVIEW_UNAVAILABLE")
	}
	var status guard.Status
	if protocol.DecodeRaw(data, &status) != nil {
		return "", errors.New("INVALID_APPROVAL_RESPONSE")
	}
	if status.State == "denied" {
		return "", errors.New("CONTENT_OR_POLICY_HELD")
	}
	if status.ID == "" || status.Digest != digest || status.Actor != s.cfg.Name || status.RunID != st.runID || status.JobID != call.ID || status.State != "pending" {
		return "", errors.New("INVALID_APPROVAL_RESPONSE")
	}
	ref := guard.Ref{ID: status.ID, Digest: digest, InputDigest: inputDigest, RunID: st.runID, JobID: call.ID, Actor: s.cfg.Name}
	st.mu.Lock()
	if st.closed {
		st.mu.Unlock()
		s.cancelApprovals(st)
		return "", errors.New("TASK_CANCELLED")
	}
	job := st.pending[call.ID]
	job.waiting = true
	job.approvalID = ref.ID
	job.digest = digest
	job.inputDigest = inputDigest
	st.pending[call.ID] = job
	st.seen = st.gen
	st.mu.Unlock()
	s.progress(st, "waiting_approval")
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for status.State == "pending" {
		if time.Now().Unix() >= status.Expires {
			return "", errors.New("APPROVAL_EXPIRED")
		}
		select {
		case <-st.ctx.Done():
			s.cancelApprovals(st)
			return "", errors.New("TASK_CANCELLED")
		case <-ticker.C:
		}
		ctx, cancel := context.WithTimeout(st.ctx, 3*time.Second)
		data, err = s.Call(ctx, "security", "approval_status", ref, st.trace, "")
		cancel()
		if err != nil {
			return "", errors.New("APPROVAL_UNAVAILABLE")
		}
		if protocol.DecodeRaw(data, &status) != nil || status.ID != ref.ID || status.Digest != digest {
			return "", errors.New("INVALID_APPROVAL_RESPONSE")
		}
	}
	if status.State != "approved" {
		return "", errors.New("APPROVAL_NOT_GRANTED")
	}
	// The execution clock and semaphore start only after human approval.
	ctx, cancel = context.WithTimeout(st.ctx, s.toolTimeout())
	defer cancel()
	if sem := s.toolSem(st.cid); sem != nil {
		select {
		case sem <- struct{}{}:
			defer func() { <-sem }()
		case <-ctx.Done():
			return "", errors.New("TASK_CANCELLED_OR_BUSY")
		}
	}
	st.mu.Lock()
	if st.closed {
		st.mu.Unlock()
		return "", errors.New("TASK_CANCELLED")
	}
	job = st.pending[call.ID]
	job.waiting = false
	st.pending[call.ID] = job
	st.mu.Unlock()
	s.progress(st, "executing")
	data, err = s.Call(ctx, svc, "guarded_execute", guard.Execute{Approval: ref, Operation: proposal.Operation, Session: st.cid}, st.trace, "")
	if err != nil {
		return "", errors.New("EXECUTION_UNCONFIRMED_NO_RETRY")
	}
	return rawToJSONText(data), nil
}

func (s *Server) guardCommit(ctx context.Context, env protocol.Envelope, in protocol.JumpPayload) (any, error) {
	if s.cfg.Guard == nil || env.From != s.cfg.Memory {
		return nil, errors.New("COMMIT_FORBIDDEN")
	}
	var ref guard.Ref
	if guard.Decode(in.Input, &ref) != nil {
		return nil, errors.New("INVALID_REFERENCE")
	}
	s.boardMu.Lock()
	defer s.boardMu.Unlock()
	for _, st := range s.board {
		if st.runID != ref.RunID {
			continue
		}
		st.mu.Lock()
		defer st.mu.Unlock()
		j, ok := st.pending[ref.JobID]
		if ctx.Err() != nil || st.closed || !ok || j.waiting || j.committed || ref.Actor != s.cfg.Name || ref.ID != j.approvalID || ref.Digest != j.digest || ref.InputDigest != j.inputDigest {
			return map[string]bool{"allowed": false}, nil
		}
		j.committed = true
		st.pending[ref.JobID] = j
		return map[string]bool{"allowed": true}, nil
	}
	return map[string]bool{"allowed": false}, nil
}

func (s *Server) reviewFinal(st *taskState, generation int64, text string) bool {
	st.mu.Lock()
	if st.closed || st.checking || st.gen != generation || len(st.pending) > 0 {
		st.mu.Unlock()
		return false
	}
	st.checking = true
	st.mu.Unlock()
	defer func() { st.mu.Lock(); st.checking = false; st.mu.Unlock() }()
	s.progress(st, "reviewing")
	task, segments, complete := s.reviewContext(st)
	request := guard.ContentRequest{Stage: "output", Task: task, RoleID: "general", Segments: segments, Candidate: text, ContextComplete: complete, Sensitivity: "private"}
	raw, err := protocol.EncodePayload(request)
	digest, digestErr := guard.ContentDigest(raw)
	allowed := false
	if err == nil && digestErr == nil {
		ctx, cancel := context.WithTimeout(st.ctx, 10*time.Second)
		data, callErr := s.Call(ctx, "security", "review_content", raw, st.trace, "")
		cancel()
		var result guard.ContentResult
		allowed = callErr == nil && protocol.DecodeRaw(data, &result) == nil && guard.OutputAllowed(result, digest)
	}
	st.mu.Lock()
	current := !st.closed && st.gen == generation && len(st.pending) == 0
	st.mu.Unlock()
	if !current {
		return false
	}
	if !allowed {
		// Program-owned status only; rejected candidate never reaches deliver or memory.store.
		s.progress(st, "held")
		s.boardClose(st)
		s.cancelApprovals(st)
		return false
	}
	return true
}
