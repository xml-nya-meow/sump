@echo off
rem Legacy shell setup is no longer required for precompiled v3 launchers.
exit /b 0
