$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot '../bin/sump-launcher.exe') -mode project
exit $LASTEXITCODE
