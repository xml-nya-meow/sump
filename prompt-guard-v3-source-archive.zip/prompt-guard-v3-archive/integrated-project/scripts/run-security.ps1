$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot '../bin/sump-launcher.exe') -mode module
exit $LASTEXITCODE
