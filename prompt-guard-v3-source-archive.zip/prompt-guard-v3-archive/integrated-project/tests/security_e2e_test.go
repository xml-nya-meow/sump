package tests

// 安全核验端到端：真实中心进程 + security 进程；核验咨询不执行命令。
import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/QAQ-awa-QAQ/sump/protocol"
)

func TestSecurityCheckE2E(t *testing.T) {
	centerBin := buildService(t, "github.com/QAQ-awa-QAQ/sump/settings-center")
	securityBin := buildService(t, "github.com/QAQ-awa-QAQ/sump/security")
	cp, sp := freePort(t), freePort(t)
	centerURL := fmt.Sprintf("ws://127.0.0.1:%d/ws", cp)
	securityURL := fmt.Sprintf("ws://127.0.0.1:%d/ws", sp)
	auditPath := filepath.Join(t.TempDir(), "security-audit.jsonl")
	startProc(t, centerBin, "-addr", fmt.Sprintf("127.0.0.1:%d", cp))
	waitWSReady(t, centerURL, 60*time.Second)
	startProc(t, securityBin, "-addr", fmt.Sprintf("127.0.0.1:%d", sp), "-center", centerURL, "-audit", auditPath)
	waitWSReady(t, securityURL, 60*time.Second)
	observer, err := protocol.Dial(centerURL, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer observer.Close()
	waitRosterHas(t, observer, "security", 30*time.Second)
	c, err := protocol.Dial(securityURL, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	for _, tc := range []struct {
		service, action, decision string
		args                      map[string]any
	}{
		{"settings-center", "ping", "allow", map[string]any{}},
		{"memory", "remember", "require_approval", map[string]any{"kind": "偏好", "content": "TEST-SECRET-DO-NOT-LOG"}},
		{"unknown", "execute", "deny", map[string]any{}},
	} {
		p := callJump(t, c, "security", "check", map[string]any{"command": map[string]any{"kind": "service_call", "service": tc.service, "action": tc.action, "input": tc.args}}, ctx)
		if !p.OK {
			t.Fatalf("核验失败: %s", p.Error)
		}
		var out struct {
			Decision string `msgpack:"decision"`
			Mode     string `msgpack:"assessment_mode"`
			Digest   string `msgpack:"command_digest"`
		}
		if err := protocol.DecodeRaw(p.Data, &out); err != nil || out.Decision != tc.decision || out.Mode != "advisory" || len(out.Digest) != 64 {
			t.Fatalf("核验结论错误: %+v %v", out, err)
		}
	}
	b, err := os.ReadFile(auditPath)
	if err != nil || strings.Count(string(b), "\n") != 3 || strings.Contains(string(b), "TEST-SECRET") {
		t.Fatalf("审计记录未保持完整脱敏: %v", err)
	}
}
